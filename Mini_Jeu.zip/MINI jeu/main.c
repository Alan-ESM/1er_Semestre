#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "pair_impair.h"
#include "ordre.h"

int main()
{
    unsigned short int choix;
    printf("\033[32m Bienvenue dans notre menu.  ?\n");
    printf("Je suis pret a jouer a plusieurs jeux ! Voici quelques suggestions :\n");
    printf("\t1- Paire ou impaire.\n");
    printf("\t2- Ordonner.\n");
    printf("\t3- Retour\n");
    scanf("%hu", &choix);

    switch(choix){
    case 1:
        programmePairImpair();
        break;
    case 2:
        ProgrammeOrdre();
        break;
    case 3:
        break;
    }

    return 0;
}
