#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Fonction de comparaison pour qsort (ordre decroissant)
int classer(const void *a, const void *b) {
    return (*(int*)b - *(int*)a);  // Inverse pour tri decroissant
}

void programmeClasserNombre() {
    printf("Bienvenue au programme pour classer les nombres.\n");

    int *tableau = NULL;  // Tableau dynamique
    int taille = 0;
    char saisir[50];  // Chaine pour stocker l'entree utilisateur

    while (1) {
        printf("Veuillez entrer un nombre ou 'fin' pour arreter :\n> ");
        scanf("%s", saisir);

        // Verifier si l'utilisateur veut arreter
        if (strcmp(strlwr(saisir), "fin") == 0) {
            break;
        }

        int tmp = atoi(saisir);  // Convertir la chaine en entier

        // Reallouer de la memoire pour le tableau
        int *tmptableau = realloc(tableau, (taille + 1) * sizeof(int));
        if (tmptableau == NULL) {
            printf("Probleme d'allocation memoire !\n");
            free(tableau);
            return;
        }

        tableau = tmptableau;
        tableau[taille] = tmp;
        taille++;
    }

    // Verifier s'il y a des elements a trier
    if (taille == 0) {
        printf("Aucun element enregistre.\n");
        return;
    }

    // Trier le tableau en ordre decroissant
    qsort(tableau, taille, sizeof(int), classer);

    // Afficher les nombres tries
    printf("\nNombres tries en ordre decroissant :\n");
    for (int i = 0; i < taille; i++) {
        printf("%d\n", tableau[i]);
    }

    free(tableau);  // Liberer la memoire
}

void ProgrammeOrdre() {
    char choix;

    printf("\n Que voulez-vous ordonner ?\n");
    printf("\ta - Classer les nombres en ordre decroissant\n");
    printf("\tb - Classer les Etudiant(e) \n");

    scanf(" %c", &choix);  // Lire un caractere (avec espace pour eviter le buffer)

    switch (choix) {
        case 'a':
            programmeClasserNombre();
            break;
        case 'b':
            etudiant();
            break;
        default:
            printf("Option invalide !\n");
    }
}

void etudiant() {
// Structure pour stocker un �tudiant
typedef struct {
    int age;
    char nom[50];
} Etudiant;

// Fonction de comparaison pour trier par �ge d�croissant
int comparer(const void *a, const void *b) {
    return ((Etudiant *)b)->age - ((Etudiant *)a)->age;
}
    Etudiant *tableau = NULL; // Tableau dynamique
    int taille = 0;
    char saisir[50]; // Chaine pour stocker l'entr�e utilisateur

    while (1) {
        Etudiant tmp;
        printf("Veuillez entrer l'age et le nom de l'etudiant (ou 'fin' pour arreter) :\n> ");
        scanf("%s", saisir);

        // V�rifier si l'utilisateur veut arr�ter
        if (strcasecmp(saisir, "fin") == 0) {
            break;
        }

        // Convertir l'age en entier
        tmp.age = atoi(saisir);
        scanf("%49s", tmp.nom); // Lire le nom

        // R�allouer de la m�moire pour le tableau
        Etudiant *tmptableau = realloc(tableau, (taille + 1) * sizeof(Etudiant));
        if (tmptableau == NULL) {
            printf("Probl�me d'allocation memoire !\n");
            free(tableau);
            return;
        }

        tableau = tmptableau;
        tableau[taille] = tmp;
        taille++;
    }

    // V�rifier s'il y a des �tudiants � trier
    if (taille == 0) {
        printf("\033[31m Aucun etudiant enregistre.\n");
        return;
    }

    // Trier les �tudiants en ordre d�croissant d'�ge
    qsort(tableau, taille, sizeof(Etudiant), comparer);

    // Afficher les �tudiants tri�s
    printf("\nListe des �tudiants class�s par �ge (du plus grand au plus petit) :\n");
    for (int i = 0; i < taille; i++) {
        printf("Nom: %s, Age: %d\n", tableau[i].nom, tableau[i].age);
    }

    free(tableau); // Lib�rer la m�moire
}
