#include "pair_impair.h"
#include <stdio.h>
#include <stdbool.h>

// Codes de couleur ANSI
#define RESET   "\033[32m"
#define RED     "\033[31m"

bool est_pair(int n) {
    return n % 2 == 0;
}

void au_carre(int n) {
    n *= n; // Note : Cette fonction ne modifie pas n dans le programme principal.
}

void au_carre_pointeur(int *n) {
    (*n) = (*n) * (*n);
}

void programmePairImpair() {
    int n;
    char choix;

    do {
        printf("Bienvenue dans le programme qui verifie si un nombre est pair\n");
        printf("Veuillez entrer un nombre : ");

        if (scanf("%d", &n) != 1) {
            printf(RED "Erreur : Veuillez entrer un nombre valide.\n" RESET);
            // Nettoyage du buffer d'entree
            while(getchar() != '\n');
            continue; // Recommence la boucle
        }

        printf(est_pair(n) ? "Ce nombre est pair.\n" : "Ce nombre est impair.\n");

        // Affichage avant d'elever au carre
        printf("On �l�ve %d au carre.\n", n);

        // Elever au carre par valeur (n ne changera pas ici)
        au_carre(n);

        // Elever au carre par pointeur (modifie n)
        au_carre_pointeur(&n);
        printf("Cela vaut : %d\n", n);

        // Demander � l'utilisateur s'il veut continuer
        printf("Voulez-vous verifier un autre nombre ? (o/n) : ");
        scanf(" %c", &choix); // L'espace avant %c ignore les espaces blancs

    } while (choix == 'o' || choix == 'O');
}
