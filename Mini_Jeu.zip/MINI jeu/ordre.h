#ifndef ORDRE_H_INCLUDED
#define ORDRE_H_INCLUDED

void ProgrammeOrdre();

void etudiant();

int programmeClasserNombre();

#endif // ORDRE_H_INCLUDED
