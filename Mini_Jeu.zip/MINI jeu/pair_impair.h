#ifndef PAIR_IMPAIR_H_INCLUDED
#define PAIR_IMPAIR_H_INCLUDED
#include <stdbool.h>

bool est_pair(int n);
void au_carre(int n);
void au_carre_pointeur(int *n);
void programmePairImpair();

#endif // PAIR_IMPAIR_H_INCLUDED
