#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "Etudiants.h"
#define RED     "\x1B[31m"
#define GREEN   "\x1B[32m"
#define YELLOW  "\x1B[33m"
#define BLUE    "\x1B[34m"
#define MAGENTA "\x1B[35m"
#define CYAN    "\x1B[36m"
#define RESET   "\x1B[0m"

#define MAX_COURS 50



void menu_non_otaku (){

        int choix;
        printf("\033[36m\n\n\t\t\t\t=================================================================\n");
        printf("\t\t\t\tBIENVENUE DANS NOTRE APPLICATION DE GESTION DES ETUDIANTS !\n");
        printf("\t\t\t\t=================================================================\n\n");
        printf("Bienvenue dans le monde educatif des etudiants !\n");

        do {
            printf("\n1. Ajouter Etudiant\n");
            printf("2. Modifier Etudiant\n");
            printf("3. Supprimer Etudiant\n");
            printf("4. Ajouter Cours\n");
            printf("5. Afficher Etudiants\n");
            printf("6. Afficher Cours\n");
            printf("7. Ajouter Note\n");
            printf("8. Ajouter Absence\n");
            printf("9. Generer Rapport\n");
            printf("10. Quitter\n");
            printf("11. Explorer le monde otaku !\n");
            printf("Choisissez une option : ");
            scanf("%d", &choix);
            getchar();

            switch (choix) {
                case 1:
                    ajouter_Etudiant();
                    break;
                case 2:
                    modifier_Etudiant();
                    break;
                case 3:
                    supprimer_Etudiant();
                    break;
                case 4:
                    ajouter_Cours();
                    break;
                case 5:
                    afficher_Etudiants();
                    break;
                case 6:
                    afficher_Cours();
                    break;
                case 7:
                    ajouter_Note();
                    break;
                case 8:
                    ajouter_Absence();
                    break;
                case 9:
                    generer_Rapport();
                    break;
                case 10:
                    printf("Au revoir !\n");
                    break;
                case 11:
                    menu();
                    break;
                default:
                    printf("Choix invalide !\n");
            }
        } while (choix != 10);
}





typedef struct {
    int id;
    char nom[50];
    char prenom[50];
    float notes[MAX_COURS];
    int absences[MAX_COURS];
} Etudiant;

typedef struct {
    int id;
    char nom[50];
} Cours;

// Fonction pour afficher la liste des etudiants

// Fonction pour afficher la liste des �tudiants
void afficherEtudiants() {
    FILE *fichier = fopen("etudiants.csv", "r");
    char ligne[256];

    if (fichier == NULL) {
        printf("Aucun �tudiant enregistr�.\n");
        return;
    }

    printf("\n--- Liste des Etudiants ---\n");
    printf("Vous entrez dans le hall de l'ecole, un lieu vibrant d'energie.\n");
    printf("Les etudiants se rassemblent, discutent, et echangent des idees.\n");
    printf("Vous etes ici pour rencontrer ceux qui composent cette communaute.\n");

    printf("----------------------------------------------------------\n");
    printf("| ID | Nom                | Prenom            |\n");
    printf("----------------------------------------------------------\n");

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);
        printf("| %2d | %-18s | %-15s |\n", e.id, e.nom, e.prenom);
    }

    printf("----------------------------------------------------------\n");
    printf("Chaque etudiant a son propre recit, ses defis et ses aspirations.\n");
    printf("Ensemble, ils forment le c�ur battant de cette institution.\n");

    fclose(fichier);
}

// Fonction pour ajouter un etudiant


void ajouterEtudiant() {
    Etudiant e;
    char input[100];
    FILE *fichier = fopen("etudiants.csv", "a");

    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier.\n");
        return;
    }

    printf("\n--- Ajouter un Etudiant ---\n");
    printf("Vous etes dans le bureau de l'administration. Vous avez deux options :\n");
    printf(GREEN "1. Passer par l'administration (choix officiel).\n" RESET);
    printf(RED "2. Passer par derriere (choix risque, l'etudiant est un rescape).\n" RESET);
    printf("Que choisissez-vous ? (1 ou 2) : ");
    fgets(input, sizeof(input), stdin);
    int choix = atoi(input);

    switch (choix) {
        case 1: {
            printf("\nVous choisissez de passer par l'administration.\n");
            printf("La secretaire vous accueille avec un sourire.\n");
            printf("Elle vous demande les informations de l'etudiant.\n");

            printf("ID de l'etudiant : ");
            fgets(input, sizeof(input), stdin);
            e.id = atoi(input);

            printf("Nom de l'etudiant : ");
            fgets(e.nom, sizeof(e.nom), stdin);
            e.nom[strcspn(e.nom, "\n")] = 0;

            printf("Prenom de l'etudiant : ");
            fgets(e.prenom, sizeof(e.prenom), stdin);
            e.prenom[strcspn(e.prenom, "\n")] = 0;

            memset(e.notes, 0, sizeof(e.notes));
            memset(e.absences, 0, sizeof(e.absences));

            fprintf(fichier, "%d,%s,%s\n", e.id, e.nom, e.prenom);
            fclose(fichier);

            printf("\nL'etudiant a ete ajoute avec succes !\n");
            printf("La secretaire vous remercie et vous offre un cafe.\n");
            break;
        }
        case 2: {
            printf("\nVous choisissez de passer par derriere.\n");
            printf("Vous traversez un couloir sombre et etroit.\n");
            printf("Soudain, vous entendez des bruits de pas derriere vous...\n");
            printf(RED "1. Vous accelerez le pas.\n" RESET);
            printf(GREEN "2. Vous vous retournez pour voir qui c'est.\n" RESET);
            printf("Que faites-vous ? (1 ou 2) : ");
            fgets(input, sizeof(input), stdin);
            int choix2 = atoi(input);

            switch (choix2) {
                case 1: {
                    printf("\nVous accelerez le pas et arrivez a la salle des archives.\n");
                    printf("Vous ajoutez l'etudiant en secret.\n");

                    printf("ID de l'etudiant : ");
                    fgets(input, sizeof(input), stdin);
                    e.id = atoi(input);

                    printf("Nom de l'etudiant : ");
                    fgets(e.nom, sizeof(e.nom), stdin);
                    e.nom[strcspn(e.nom, "\n")] = 0;

                    printf("Prenom de l'etudiant : ");
                    fgets(e.prenom, sizeof(e.prenom), stdin);
                    e.prenom[strcspn(e.prenom, "\n")] = 0;

                    memset(e.notes, 0, sizeof(e.notes));
                    memset(e.absences, 0, sizeof(e.absences));

                    fprintf(fichier, "%d,%s,%s\n", e.id, e.nom, e.prenom);
                    fclose(fichier);

                    printf("\nL'etudiant a ete ajoute avec succes, mais vous avez l'impression d'etre surveille...\n");
                    break;
                }
                case 2: {
                    printf("\nVous vous retournez et voyez une silhouette mysterieuse.\n");
                    printf("C'est une etudiante, elle vous sourit timidement.\n");
                    printf("Elle vous propose de l'aider a ajouter l'etudiant.\n");
                    printf(GREEN "1. Vous acceptez son aide.\n" RESET);
                    printf(RED "2. Vous refusez poliment.\n" RESET);
                    printf("Que faites-vous ? (1 ou 2) : ");
                    fgets(input, sizeof(input), stdin);
                    int choix3 = atoi(input);

                    switch (choix3) {
                        case 1: {
                            printf("\nVous acceptez son aide et ajoutez l'etudiant ensemble.\n");

                            printf("ID de l'etudiant : ");
                            fgets(input, sizeof(input), stdin);
                            e.id = atoi(input);

                            printf("Nom de l'etudiant : ");
                            fgets(e.nom, sizeof(e.nom), stdin);
                            e.nom[strcspn(e.nom, "\n")] = 0;

                            printf("Prenom de l'etudiant : ");
                            fgets(e.prenom, sizeof(e.prenom), stdin);
                            e.prenom[strcspn(e.prenom, "\n")] = 0;

                            memset(e.notes, 0, sizeof(e.notes));
                            memset(e.absences, 0, sizeof(e.absences));

                            fprintf(fichier, "%d,%s,%s\n", e.id, e.nom, e.prenom);
                            fclose(fichier);

                            printf("\nL'etudiant a ete ajoute avec succes.\n");
                            printf("L'etudiante vous remercie et vous invite a prendre un cafe.\n");
                            printf("Une romance commence peut-etre...\n");
                            break;
                        }
                        case 2: {
                            printf("\nVous refusez poliment et ajoutez l'etudiant seul.\n");

                            printf("ID de l'etudiant : ");
                            fgets(input, sizeof(input), stdin);
                            e.id = atoi(input);

                            printf("Nom de l'etudiant : ");
                            fgets(e.nom, sizeof(e.nom), stdin);
                            e.nom[strcspn(e.nom, "\n")] = 0;

                            printf("Prenom de l'etudiant : ");
                            fgets(e.prenom, sizeof(e.prenom), stdin);
                            e.prenom[strcspn(e.prenom, "\n")] = 0;

                            memset(e.notes, 0, sizeof(e.notes));
                            memset(e.absences, 0, sizeof(e.absences));

                            fprintf(fichier, "%d,%s,%s\n", e.id, e.nom, e.prenom);
                            fclose(fichier);

                            printf("\nL'etudiant a ete ajoute avec succes.\n");
                            printf("L'etudiante semble decue et s'eloigne.\n");

                            printf(BLUE "1. Vous la laissez partir.\n" RESET);
                            printf(RED "2. Vous la rattrapez.\n" RESET);
                            printf("Que faites-vous ? (1 ou 2) : ");
                            fgets(input, sizeof(input), stdin);
                            int choix4 = atoi(input);

                            switch (choix4) {
                                case 1: {
                                    printf("\nVous la laissez partir. Mais soudain, elle se retourne...\n");
                                    printf(RED "Aie ! Ce n'etait pas un bon choix. Il s'avere que c'etait un fantome !\n" RESET);
                                    printf("Voulez-vous entendre son histoire ?\n");
                                    printf(BLUE "1. Oui.\n" RESET);
                                    printf(RED "2. Non.\n" RESET);
                                    printf("Que choisissez-vous ? (1 ou 2) : ");
                                    fgets(input, sizeof(input), stdin);
                                    int choix5 = atoi(input);

                                    switch (choix5) {
                                        case 1: {
                                            printf("\nVous decidez d'ecouter son histoire.\n");
                                            printf(MAGENTA "Elle vous raconte son histoire...\n" RESET);
                                            printf("Il y a longtemps, elle etait une etudiante brillante nommee Aiko.\n");
                                            printf("Un jour, elle a ete accuse a tort de vol par ses camarades.\n");
                                            printf("Hontee et abandonnee, elle s'est suicidee dans ce meme couloir.\n");
                                            printf("Depuis, son esprit erre, cherchant a se venger de ceux qui la croisent.\n");
                                            printf("En echange de votre silence a jamais, elle decide de vous epargner.\n");
                                            printf("Mais elle exige votre oeil gauche comme gage.\n");
                                            printf("Vous acceptez et perdez un oeil, mais vous survivez.\n");
                                            printf("L'etudiant n'a pas ete ajoute.\n");
                                            break;
                                        }
                                        case 2: {
                                            printf("\nVous refusez d'ecouter son histoire.\n");
                                            printf(RED "Le fantome, rempli de haine, vous tue sur place.\n" RESET);
                                            printf("Vous n'avez pas reussi a ajouter l'etudiant.\n");
                                            break;
                                        }
                                        default: {
                                            printf("\nChoix invalide. Le fantome vous tue par defaut.\n");
                                            break;
                                        }
                                    }
                                    break;
                                }
                                case 2: {
                                    printf("\nVous la rattrapez et lui proposez de prendre un cafe.\n");
                                    printf("Elle sourit et accepte. Une romance commence peut-etre...\n");
                                    printf("L'etudiant a ete ajoute avec succes.\n");
                                    break;
                                }
                                default: {
                                    printf("\nChoix invalide. L'etudiante s'eloigne.\n");
                                    break;
                                }
                            }
                            break;
                        }
                        default: {
                            printf("\nChoix invalide. Retour au bureau de l'administration.\n");
                            break;
                        }
                    }
                    break;
                }
                default: {
                    printf("\nChoix invalide. Retour au bureau de l'administration.\n");
                    break;
                }
            }
            break;
        }
        default: {
            printf("\nChoix invalide. Retour au menu principal.\n");
            break;
        }
    }
}

// Fonction pour modifier un etudiant

void modifierEtudiant() {
    int id_a_modifier;
    char ligne[256];
    FILE *fichier = fopen("etudiants.csv", "r+");
    FILE *fichier_temp = fopen("temp.csv", "w");

    if (fichier == NULL || fichier_temp == NULL) {
        printf(RED "Erreur : impossible d'ouvrir le fichier.\n" RESET);
        return;
    }

    printf("\n--- Modifier un Etudiant ---\n");
    printf("Vous vous rendez au bureau de l'administration pour modifier votre nom.\n");
    printf("Mais quelque chose ne semble pas normal...\n");
    printf("L'administrateur vous regarde d'un air suspicieux.\n");
    printf("Il vous demande votre ID : ");
    scanf("%d", &id_a_modifier);
    getchar();  // Consommer le retour a la ligne restant

    int found = 0;
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);

        if (e.id == id_a_modifier) {
            found = 1;
            printf("\nVous avez trouve votre profil : %s %s.\n", e.nom, e.prenom);
            printf("Mais soudain, l'administrateur vous regarde avec haine.\n");
            printf(MAGENTA "Administrateur : 'Je sais qui tu es. Tu es le fils de Kazuo Tanaka, le chef des yakuza !'\n" RESET);
            printf(MAGENTA "Administrateur : 'Ton clan a tue ma femme, Umio, lors d'une fusillade il y a dix ans !'\n" RESET);
            printf("Il sort une arme et la pointe vers vous.\n");

            printf("1. Vous baissez pour esquiver.\n");
            printf("2. Vous restez calme.\n");
            printf("Que faites-vous ? (1 ou 2) : ");
            char choix[10];
            fgets(choix, sizeof(choix), stdin);
            int action = atoi(choix);

            switch (action) {
                case 1: {
                    printf("\nVous vous baissez rapidement. La balle vous effleure l'epaule.\n");
                    printf("Vous bondissez sur lui et une lutte intense commence.\n");
                    printf("Vous parvenez a le desarmer et le mettre au sol.\n");
                    printf(MAGENTA "Administrateur : 'Je te jure, je te denoncerai !'\n" RESET);
                    printf("1. L'achever.\n");
                    printf("2. L'epargner.\n");
                    printf("Que faites-vous ? (1 ou 2) : ");
                    fgets(choix, sizeof(choix), stdin);
                    int choix2 = atoi(choix);

                    switch (choix2) {
                        case 1: {
                            printf("\nVous decidez de l'achever pour proteger votre secret.\n");
                            printf(RED "Vous etes maintenant un meurtrier. Mais vous etes le fils d'un yakuza, vous avez la tete dure.\n" RESET);
                            printf("Vous quittez le bureau, sachant que votre vie ne sera plus jamais la meme.\n");
                            break;
                        }
                        case 2: {
                            printf("\nVous decidez de l'epargner, malgre tout.\n");
                            printf(CYAN "Au moment ou vous vous eloignez, Yume, votre amie d'enfance, entre en courant.\n" RESET);
                            printf(CYAN "Yume : 'Papa ! Qu'est-ce qui se passe ici ?'\n" RESET);
                            printf("Vous realisez avec horreur que l'administrateur est le pere de Yume.\n");
                            printf("1. Decouvrir les dernieres paroles d'Umio.\n");
                            printf("2. Ignorer et partir.\n");
                            printf("Que faites-vous ? (1 ou 2) : ");
                            fgets(choix, sizeof(choix), stdin);
                            int choix3 = atoi(choix);

                            switch (choix3) {
                                case 1: {
                                    printf("\n--- Les dernieres paroles d'Umio ---\n");
                                    printf("Il y a dix ans, lors de la fusillade, vous etiez present.\n");
                                    printf("Umio, la mere de Yume, etait gravement blessee.\n");
                                    printf("Avant de mourir, elle vous a regarde droit dans les yeux et a murmure :\n");
                                    printf(MAGENTA "'Veille sur Yume... Je t'en supplie.'\n" RESET);
                                    printf("Ces mots vous ont marque, mais vous etes le fils d'un yakuza. Vous avez la tete dure.\n");
                                    printf("Vous vous eloignez, sachant que votre amitie avec Yume est maintenant brisee.\n");
                                    break;
                                }
                                case 2: {
                                    printf("\nVous ignorez les dernieres paroles et partez rapidement.\n");
                                    printf("Mais vous savez que ces mots vous suivront pour toujours.\n");
                                    break;
                                }
                                default: {
                                    printf("\nChoix invalide. Vous partez sans rien dire.\n");
                                    break;
                                }
                            }
                            break;
                        }
                        default: {
                            printf("\nChoix invalide. Vous partez sans rien faire.\n");
                            break;
                        }
                    }
                    break;
                }
                case 2: {
                    printf("\nVous restez calme, malgre la peur qui vous envahit.\n");
                    printf("La main de l'administrateur tremble a cause d'une ancienne blessure.\n");
                    printf("Il tire, mais la balle vous rate de justesse.\n");
                    printf("Vous le frappez d'un coup de pied rapide et precis, l'assommant sur le coup.\n");
                    printf(MAGENTA "Administrateur (avant de tomber) : 'Je te denoncerai...'\n" RESET);
                    printf("1. L'achever.\n");
                    printf("2. L'epargner.\n");
                    printf("Que faites-vous ? (1 ou 2) : ");
                    fgets(choix, sizeof(choix), stdin);
                    int choix2 = atoi(choix);

                    switch (choix2) {
                        case 1: {
                            printf("\nVous decidez de l'achever pour proteger votre secret.\n");
                            printf(RED "Vous etes maintenant un meurtrier. Mais vous etes le fils d'un yakuza, vous avez la tete dure.\n" RESET);
                            printf("Vous quittez le bureau, sachant que votre vie ne sera plus jamais la meme.\n");
                            break;
                        }
                        case 2: {
                            printf("\nVous decidez de l'epargner, malgre tout.\n");
                            printf(CYAN "Au moment ou vous vous eloignez, Yume, votre amie d'enfance, entre en courant.\n" RESET);
                            printf(CYAN "Yume : 'Papa ! Qu'est-ce qui se passe ici ?'\n" RESET);
                            printf("Vous realisez avec horreur que l'administrateur est le pere de Yume.\n");
                            printf("1. Decouvrir les dernieres paroles d'Umio.\n");
                            printf("2. Ignorer et partir.\n");
                            printf("Que faites-vous ? (1 ou 2) : ");
                            fgets(choix, sizeof(choix), stdin);
                            int choix3 = atoi(choix);

                            switch (choix3) {
                                case 1: {
                                    printf("\n--- Les dernieres paroles d'Umio ---\n");
                                    printf("Il y a dix ans, lors de la fusillade, vous etiez present.\n");
                                    printf("Umio, la mere de Yume, etait gravement blessee.\n");
                                    printf("Avant de mourir, elle vous a regarde droit dans les yeux et a murmure :\n");
                                    printf(MAGENTA "'Veille sur Yume... Je t'en supplie.'\n" RESET);
                                    printf("Ces mots vous ont marque, mais vous etes le fils d'un yakuza. Vous avez la tete dure.\n");
                                    printf("Vous vous eloignez, sachant que votre amitie avec Yume est maintenant brisee.\n");
                                    break;
                                }
                                case 2: {
                                    printf("\nVous ignorez les dernieres paroles et partez rapidement.\n");
                                    printf("Mais vous savez que ces mots vous suivront pour toujours.\n");
                                    break;
                                }
                                default: {
                                    printf("\nChoix invalide. Vous partez sans rien dire.\n");
                                    break;
                                }
                            }
                            break;
                        }
                        default: {
                            printf("\nChoix invalide. Vous partez sans rien faire.\n");
                            break;
                        }
                    }
                    break;
                }
                default: {
                    printf("\nChoix invalide. L'administrateur vous tire dessus et vous tue.\n");
                    printf(RED "Vous n'avez pas reussi a modifier votre nom.\n" RESET);
                    found = 0;  // Annuler la modification
                    break;
                }
            }
        }

        fprintf(fichier_temp, "%d,%s,%s\n", e.id, e.nom, e.prenom);
    }

    fclose(fichier);
    fclose(fichier_temp);
    remove("etudiants.csv");
    rename("temp.csv", "etudiants.csv");

    if (found) {
        printf(GREEN "Etudiant modifie avec succes !\n" RESET);
    } else {
        printf(RED "Etudiant non trouve ou modification echouee.\n" RESET);
    }
}

// Fonction pour supprimer un etudiant

void supprimerEtudiant() {
    int id_a_supprimer;
    char ligne[256];
    FILE *fichier = fopen("etudiants.csv", "r");
    FILE *fichier_temp = fopen("temp.csv", "w");

    if (fichier == NULL || fichier_temp == NULL) {
        printf(RED "Erreur : impossible d'ouvrir le fichier.\n" RESET);
        return;
    }

    printf("\n--- Supprimer un Etudiant ---\n");
    printf("Vous vous rendez au bureau de l'administration pour supprimer un etudiant.\n");
    printf("Mais cette fois, il ne s'agit pas d'une simple formalite...\n");
    printf("Vous avez commis l'impensable : vous avez tue un de vos camarades.\n");
    printf("Le corps est deja cache, mais vous devez effacer toute trace de son existence.\n");
    printf("Vous devez supprimer son nom de l'ecole.\n");
    printf("Entrez l'ID de l'etudiant a supprimer : ");
    scanf("%d", &id_a_supprimer);
    getchar();  // Consommer le retour a la ligne restant

    int found = 0;
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);

        if (e.id != id_a_supprimer) {
            fprintf(fichier_temp, "%d,%s,%s\n", e.id, e.nom, e.prenom);
        } else {
            found = 1;
            printf("\nVous avez trouve l'etudiant : %s %s.\n", e.nom, e.prenom);
            printf("Vous commencez a effacer son nom des registres...\n");
            printf("Mais soudain, vous entendez des pas derriere vous.\n");
            printf("1. Vous vous cachez.\n");
            printf("2. Vous faites face a l'intrus.\n");
            printf("Que faites-vous ? (1 ou 2) : ");
            char choix[10];
            fgets(choix, sizeof(choix), stdin);
            int action = atoi(choix);

            switch (action) {
                case 1: {
                    printf("\nVous vous cachez rapidement derriere un bureau.\n");
                    printf("Un garde de securite entre dans la piece.\n");
                    printf("Il regarde autour de lui, mais ne vous voit pas.\n");
                    printf("1. Attendre qu'il parte.\n");
                    printf("2. L'attaquer par derriere.\n");
                    printf("Que faites-vous ? (1 ou 2) : ");
                    fgets(choix, sizeof(choix), stdin);
                    int choix2 = atoi(choix);

                    switch (choix2) {
                        case 1: {
                            printf("\nVous attendez patiemment que le garde parte.\n");
                            printf("Apres quelques minutes, il quitte la piece.\n");
                            printf("Vous terminez d'effacer le nom de l'etudiant.\n");
                            printf(GREEN "L'etudiant a ete supprime avec succes. Personne ne saura jamais ce qui s'est passe...\n" RESET);
                            break;
                        }
                        case 2: {
                            printf("\nVous decidez de l'attaquer par derriere.\n");
                            printf("Vous le frappez avec un objet lourd, l'assommant sur le coup.\n");
                            printf(RED "Vous avez maintenant un autre corps a cacher...\n" RESET);
                            printf("Vous terminez d'effacer le nom de l'etudiant.\n");
                            printf(GREEN "L'etudiant a ete supprime avec succes, mais le garde manque a l'appel.\n" RESET);
                            break;
                        }
                        default: {
                            printf("\nChoix invalide. Le garde vous decouvre et vous arrete.\n");
                            printf(RED "Vous n'avez pas reussi a supprimer l'etudiant.\n" RESET);
                            found = 0;  // Annuler la suppression
                            break;
                        }
                    }
                    break;
                }
                case 2: {
                    printf("\nVous faites face a l'intrus. C'est un professeur.\n");
                    printf(MAGENTA "Professeur : 'Que fais-tu ici a cette heure ?'\n" RESET);
                    printf("1. Inventer une excuse.\n");
                    printf("2. L'attaquer pour le reduire au silence.\n");
                    printf("Que faites-vous ? (1 ou 2) : ");
                    fgets(choix, sizeof(choix), stdin);
                    int choix2 = atoi(choix);

                    switch (choix2) {
                        case 1: {
                            printf("\nVous inventez une excuse rapide.\n");
                            printf("Vous dites que vous cherchiez des documents pour un projet.\n");
                            printf(MAGENTA "Professeur : 'D'accord, mais ne traine pas trop longtemps.'\n" RESET);
                            printf("Il quitte la piece, et vous terminez d'effacer le nom de l'etudiant.\n");
                            printf(GREEN "L'etudiant a ete supprime avec succes. Personne ne saura jamais ce qui s'est passe...\n" RESET);
                            break;
                        }
                        case 2: {
                            printf("\nVous decidez de l'attaquer pour le reduire au silence.\n");
                            printf("Une lutte intense s'ensuit, mais vous parvenez a le ma�triser.\n");
                            printf(RED "Vous avez maintenant un autre corps a cacher...\n" RESET);
                            printf("Vous terminez d'effacer le nom de l'etudiant.\n");
                            printf(GREEN "L'etudiant a ete supprime avec succes, mais le professeur manque a l'appel.\n" RESET);
                            break;
                        }
                        default: {
                            printf("\nChoix invalide. Le professeur vous denonce.\n");
                            printf(RED "Vous n'avez pas reussi a supprimer l'etudiant.\n" RESET);
                            found = 0;  // Annuler la suppression
                            break;
                        }
                    }
                    break;
                }
                default: {
                    printf("\nChoix invalide. Vous etes decouvert et arrete.\n");
                    printf(RED "Vous n'avez pas reussi a supprimer l'etudiant.\n" RESET);
                    found = 0;  // Annuler la suppression
                    break;
                }
            }
        }
    }

    fclose(fichier);
    fclose(fichier_temp);
    remove("etudiants.csv");
    rename("temp.csv", "etudiants.csv");

    if (found) {
        printf(GREEN "Etudiant supprime avec succes !\n" RESET);
    } else {
        printf(RED "Etudiant non trouve ou suppression echouee.\n" RESET);
    }
}

// Fonction pour ajouter un cours

void ajouterCours() {
    Cours c;
    FILE *fichier = fopen("cours.csv", "a");

    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier.\n");
        return;
    }

    printf("\n--- Ajouter un Cours ---\n");
    printf("Vous entrez dans l'antre des connaissances, le bureau des cours...\n");
    printf("Ici, vous devez ajouter un nouveau cours, mais soyez prudent.\n");
    printf("Les rumeurs disent qu'un ancien professeur hante cet endroit...\n");

    printf("ID du cours : ");
    scanf("%d", &c.id);
    getchar();  // Consommer le retour a la ligne restant

    printf("Nom du cours : ");
    fgets(c.nom, sizeof(c.nom), stdin);
    c.nom[strcspn(c.nom, "\n")] = 0;  // Enlever le retour a la ligne

    fprintf(fichier, "%d,%s\n", c.id, c.nom);
    fclose(fichier);
    printf("Vous commencez a inscrire le nouveau cours...\n");
    printf("Mais attendez, un bruit se fait entendre !\n");

    printf("1. Vous ignorez le bruit et continuez.\n");
    printf("2. Vous vous retournez pour voir ce qui se passe.\n");
    printf("3. Vous sortez pour prendre l'air.\n");
    printf("Que faites-vous ? (1, 2 ou 3) : ");

    char choix[10];
    fgets(choix, sizeof(choix), stdin);
    int action = atoi(choix);

    switch (action) {
        case 1: {
            printf("\nVous ignorez le bruit, vous vous concentrez sur votre tache.\n");
            printf("Le cours a ete ajoute avec succes !\n");
            break;
        }
        case 2: {
            printf("\nVous vous retournez et apercevez une silhouette dans l'ombre.\n");
            printf("C'est le professeur, il vous fixe avec un regard per�ant.\n");
            printf(MAGENTA "Professeur : 'Que faites-vous ici ?'\n" RESET);
            printf("1. Inventer une excuse.\n");
            printf("2. Lui demander de vous aider avec le cours.\n");
            printf("Que faites-vous ? (1 ou 2) : ");
            fgets(choix, sizeof(choix), stdin);
            int choix2 = atoi(choix);

            switch (choix2) {
                case 1: {
                    printf("\nVous inventez une excuse rapide.\n");
                    printf(MAGENTA "Professeur : 'D'accord, mais assurez-vous de bien faire votre travail.'\n" RESET);
                    printf("Le professeur s'en va, et vous terminez d'ajouter le cours avec succes !\n");
                    break;
                }
                case 2: {
                    printf("\nVous demandez de l'aide au professeur.\n");
                    printf(MAGENTA "Professeur : 'Bien, je vais vous aider.'\n" RESET);
                    printf("Ensemble, vous ajoutez le cours, renfor�ant votre lien avec le savoir.\n");
                    printf("Le cours a ete ajoute avec succes !\n");
                    break;
                }
                default: {
                    printf("\nChoix invalide. Le professeur s'impatiente et s'en va.\n");
                    printf("Le cours n'a pas pu etre ajoute.\n");
                    break;
                }
            }
            break;
        }
        case 3: {
            printf("\nVous sortez prendre l'air, le soleil brille et vous vous sentez bien.\n");
            printf("Vous croisez une personne qui attire votre attention...\n");
            printf("1. Vous engagez la conversation.\n");
            printf("2. Vous continuez votre chemin, timide.\n");
            printf("Que faites-vous ? (1 ou 2) : ");
            fgets(choix, sizeof(choix), stdin);
            int choix3 = atoi(choix);

            switch (choix3) {
                case 1: {
                    printf("\nVous engagez la conversation et d�couvrez que vous avez beaucoup en commun.\n");
                    printf("Cette rencontre marque le debut d'une belle amitie...\n");
                    printf("Ou peut-etre meme quelque chose de plus...\n");
                    printf(GREEN "Vous avez trouve votre ame soeur !\n" RESET);
                    break;
                }
                case 2: {
                    printf("\nVous continuez votre chemin, mais le regard de cette personne vous hante.\n");
                    printf("Vous vous demandez ce qui aurait pu se passer si vous aviez ose parler...\n");
                    printf(RED "Une occasion manqu�e...\n" RESET);
                    break;
                }
                default: {
                    printf("\nChoix invalide. Vous rentrez sans rien faire.\n");
                    break;
                }
            }
            break;
        }
        default: {
            printf("\nChoix invalide. Vous vous retrouvez seul dans le bureau...\n");
            printf("Le cours n'a pas pu etre ajoute.\n");
            break;
        }
    }
}

// Fonction pour afficher les cours
void afficherCours() {
    FILE *fichier = fopen("cours.csv", "r");
    char ligne[256];

    if (fichier == NULL) {
        printf("Aucun cours enregistre.\n");
        return;
    }

    printf("----------------------------------------------------------\n");
    printf("| ID | Nom                |\n");
    printf("----------------------------------------------------------\n");

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Cours c;
        sscanf(ligne, "%d,%[^,]", &c.id, c.nom);
        printf("| %2d | %-18s |\n", c.id, c.nom);
    }

    printf("----------------------------------------------------------\n");
    fclose(fichier);
}

// Fonction pour g�rer les notes
void ajouterNote() {
    int id_etudiant, id_cours;
    float note;

    printf("\n--- Ajouter une Note ---\n");
    printf("Vous entrez dans la salle des professeurs, un lieu sacre de l'apprentissage...\n");
    printf("Ici, vous devez ajouter une note pour un etudiant, mais attention...\n");
    printf("Des rumeurs circulent sur un etudiant qui a triche pour obtenir de bonnes notes...\n");

    printf("ID de l'etudiant : ");
    scanf("%d", &id_etudiant);

    printf("ID du cours : ");
    scanf("%d", &id_cours);

    printf("Note : ");
    scanf("%f", &note);

    // Exemple de v�rification de la note
    if (note < 0 || note > 20) {
        printf("La note doit etre entre 0 et 20. Operation annulee.\n");
        return;
    }

    printf("Vous commencez a inscrire la note...\n");
    printf("Mais attendez, un bruit se fait entendre dans le couloir !\n");

    printf("1. Vous ignorez le bruit et continuez.\n");
    printf("2. Vous sortez pour voir ce qui se passe.\n");
    printf("Que faites-vous ? (1 ou 2) : ");

    char choix[10];
    fgets(choix, sizeof(choix), stdin);
    int action = atoi(choix);

    switch (action) {
        case 1: {
            printf("\nVous ignorez le bruit et vous vous concentrez sur la note.\n");
            printf("La note a ete ajoutee avec succes !\n");
            break;
        }
        case 2: {
            printf("\nVous sortez dans le couloir et apercevez un groupe d'etudiants...\n");
            printf("Ils murmurent et semblent inquiets. Vous vous approchez.\n");
            printf("1. Vous demandez ce qui se passe.\n");
            printf("2. Vous les ignorez et retournez a votre bureau.\n");
            printf("Que faites-vous ? (1 ou 2) : ");
            fgets(choix, sizeof(choix), stdin);
            int choix2 = atoi(choix);

            switch (choix2) {
                case 1: {
                    printf("\nVous demandez ce qui se passe.\n");
                    printf("Un etudiant vous explique qu'ils ont des doutes sur un examen upcoming.\n");
                    printf("Vous leur donnez quelques conseils pour les aider.\n");
                    printf("En retour, ils vous remercient chaleureusement.\n");
                    printf("La note a ete ajoutee avec succes, et vous avez aide des etudiants !\n");
                    break;
                }
                case 2: {
                    printf("\nVous retournez a votre bureau, preferant ne pas vous impliquer.\n");
                    printf("La note a ete ajoutee avec succes, mais vous ne saurez jamais ce qui se passait dans le couloir.\n");
                    break;
                }
                default: {
                    printf("\nChoix invalide. Vous retournez a votre bureau sans rien faire.\n");
                    break;
                }
            }
            break;
        }
        default: {
            printf("\nChoix invalide. Vous vous retrouvez seul dans la salle des professeurs...\n");
            printf("La note n'a pas pu etre ajoutee.\n");
            break;
        }
    }
}

// Fonction pour g�rer les absences

void ajouterAbsence() {
    int id_etudiant, id_cours, nombre_absences;
    FILE *fichier_absences = fopen("absences.csv", "a");

    if (fichier_absences == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier des absences.\n");
        return;
    }

    printf("\n--- Ajouter des Absences ---\n");
    printf("Vous entrez dans le bureau de l'administration, un lieu charg� de tension...\n");
    printf("Les murs sont tapissas de diplomes, mais votre avenir ici est incertain.\n");
    printf("Vous avez decide de prendre une decision audacieuse : accumuler des absences.\n");
    printf("Votre plan est simple, mais risque : vous devez vous faire renvoyer du college.\n");
    printf("Cela vous permettra d'integrer une nouvelle �cole sous un nouveau nom, loin de votre passe...\n");

    printf("ID de l'�tudiant : ");
    scanf("%d", &id_etudiant);

    printf("ID du cours : ");
    scanf("%d", &id_cours);

    printf("Nombre d'absences a ajouter : ");
    scanf("%d", &nombre_absences);

    // Ajout des absences au fichier
    fprintf(fichier_absences, "%d,%d,%d\n", id_etudiant, id_cours, nombre_absences);

    // Histoire de la d�cision
    printf("\nVous prenez une profonde respiration, sachant que chaque absence vous rapproche de votre objectif.\n");
    printf("Vous imaginez deja votre nouvelle vie, loin de ce college qui vous oppresse...\n");
    printf("Vous avez ajout� %d absence(s) pour l'etudiant avec ID %d dans le cours avec ID %d.\n", nombre_absences, id_etudiant, id_cours);
    printf("Le vent de la liberte souffle deja dans votre direction...\n");

    fclose(fichier_absences);
}

// Fonction pour g�n�rer des rapports

void genererRapport() {
    FILE *fichier_etudiants = fopen("etudiants.csv", "r");
    FILE *fichier_notes = fopen("notes.csv", "r");
    FILE *fichier_absences = fopen("absences.csv", "r");
    FILE *fichier_rapport = fopen("rapport.csv", "w");
    char ligne[256];

    if (fichier_etudiants == NULL) {
        printf("Aucun �tudiant enregistr�.\n");
        return;
    }

    // �crire l'en-t�te du rapport
    fprintf(fichier_rapport, "ID,Nom,Prenom,Note,Absences\n");

    // Lire les �tudiants et g�n�rer le rapport
    while (fgets(ligne, sizeof(ligne), fichier_etudiants) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);

        // Initialiser note et absences
        float note = -1; // -1 signifie pas de note
        int absences = 0;

        // V�rifier les notes
        rewind(fichier_notes);
        while (fgets(ligne, sizeof(ligne), fichier_notes) != NULL) {
            int id_etudiant, id_cours;
            float note_temp;
            sscanf(ligne, "%d,%[^,],%d,%f", &id_etudiant, e.nom, &id_cours, &note_temp);
            if (id_etudiant == e.id) {
                note = note_temp; // Prendre la note la plus r�cente
            }
        }

        // V�rifier les absences
        rewind(fichier_absences);
        while (fgets(ligne, sizeof(ligne), fichier_absences) != NULL) {
            int id_etudiant, id_cours, nombre_absences;
            sscanf(ligne, "%d,%d,%d", &id_etudiant, &id_cours, &nombre_absences);
            if (id_etudiant == e.id) {
                absences += nombre_absences; // Additionner les absences
            }
        }

        // �crire les informations dans le rapport
        fprintf(fichier_rapport, "%d,%s,%s,%.2f,%d\n", e.id, e.nom, e.prenom, note, absences);
        printf("ID: %d, Nom: %s, Prenom: %s, Note: %.2f, Absences: %d\n", e.id, e.nom, e.prenom, note, absences);
    }

    fclose(fichier_etudiants);
    fclose(fichier_notes);
    fclose(fichier_absences);
    fclose(fichier_rapport);
    printf("Le rapport a ete genere avec succes dans le fichier rapport.csv.\n");
}

// Fonction principale
void menu() {
    int choix;

        printf("\nYokoso! Anata wa gakko no sekai ni hairu...\n");
        printf("Koko ni wa, sorezore no gakusei no monogatari ga arimasu.\n");
    do{
            printf("\033[36m\n\t\t\t\t=================================================================\n");
            printf("\t\t\t\tBIENVENUE DANS NOTRE APPLICATION DE GESTION DES ETUDIANTS !\n");
            printf("\t\t\t\t=================================================================\n\n");
            printf("\t\t\t\t| 1. Gakusei wo tsuika                                         |\n");
            printf("\t\t\t\t| 2. Gakusei wo henkou                                         |\n");
            printf("\t\t\t\t| 3. Gakusei wo sakujyo                                        |\n");
            printf("\t\t\t\t| 4. Kyo wo tsuika                                             |\n");
            printf("\t\t\t\t| 5. Gakusei wo hyouji                                         |\n");
            printf("\t\t\t\t| 6. Kyo wo hyouji                                             |\n");
            printf("\t\t\t\t| 7. Ten wo tsuika                                             |\n");
            printf("\t\t\t\t| 8. Kyoshitsu wo tsuika                                       |\n");
            printf("\t\t\t\t| 9. Raport wo seisei                                          |\n");
            printf("\t\t\t\t| 10. Kyuushutsu                                               |\n");
            printf("\t\t\t\t| 11. Explorer le monde normal                                 |\n");
            printf("\t\t\t\t=================================================================\n");
            printf("Anata no opushon wo erande kudasai: ");
            scanf("%d", &choix);
            getchar();  // Pour consommer le caractere de nouvelle ligne restant

            switch (choix) {
                case 1:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tKONO BASHO NI OKOSHI ITADAKI, KOKORO YORI KANSHA MOSHIAGEMASU !!!!\n");
                    printf("\t\t\t================================================================================\n");

                    ajouterEtudiant();

                    break;

                case 2:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tGakusei no henkou wo shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    modifierEtudiant();
                    break;

                case 3:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tGakusei no sakujyo wo shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    supprimerEtudiant();
                    break;

                case 4:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tKYO NO TSUIKA WO SHIMASU...\n");
                    printf("\t\t\t================================================================================\n");
                    ajouterCours();
                    break;

                case 5:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tGakusei no hyouji wo shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    afficherEtudiants();
                    break;

                case 6:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tKyo no hyouji wo shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    afficherCours();
                    break;

                case 7:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tTen wo tsuika shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    ajouterNote();
                    break;

                case 8:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tKyoshitsu wo tsuika shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    ajouterAbsence();
                    break;

                case 9:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tRaport wo seisei shimasu...\n");
                    printf("\t\t\t================================================================================\n");
                    genererRapport();
                    break;

                case 10:
                    printf("\n\t\t\t================================================================================\n");
                    printf("\t\t\t\tKONO BASHO NI OKOSHI ITADAKI, KOKORO YORI KANSHA MOSHIAGEMASU !!!!\n");
                    printf("\t\t\t================================================================================\n");
                    printf("Sayonara!\n");
                    break;
                case 11:
                    menu_non_otaku();
                    break;
                default:
                    printf("Mochiron, erabareta opushon wa arimasen!\n");
            }
    } while (choix != 10);

}


// Fonction pour afficher la liste des etudiants
void afficher_Etudiants() {
    FILE *fichier = fopen("etudiants.csv", "r");
    char ligne[256];

    if (fichier == NULL) {
        printf("Aucun etudiant enregistre.\n");
        return;
    }

    printf("----------------------------------------------------------\n");
    printf("| ID | Nom                | Prenom            |\n");
    printf("----------------------------------------------------------\n");

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);
        printf("| %2d | %-18s | %-15s |\n", e.id, e.nom, e.prenom);
    }

    printf("----------------------------------------------------------\n");
    fclose(fichier);
}

// Fonction pour ajouter un etudiant
void ajouter_Etudiant() {
    Etudiant e;
    char input[100];
    FILE *fichier = fopen("etudiants.csv", "a");

    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier.\n");
        return;
    }

    printf("ID de l'etudiant : ");
    fgets(input, sizeof(input), stdin);
    e.id = atoi(input);

    printf("Nom de l'etudiant : ");
    fgets(e.nom, sizeof(e.nom), stdin);
    e.nom[strcspn(e.nom, "\n")] = 0;  // Enlever le retour a la ligne

    printf("Prenom de l'etudiant : ");
    fgets(e.prenom, sizeof(e.prenom), stdin);
    e.prenom[strcspn(e.prenom, "\n")] = 0;  // Enlever le retour a la ligne

    memset(e.notes, 0, sizeof(e.notes));
    memset(e.absences, 0, sizeof(e.absences));

    fprintf(fichier, "%d,%s,%s\n", e.id, e.nom, e.prenom);
    fclose(fichier);
    printf("Etudiant ajoute avec succes !\n");
}

// Fonction pour modifier un etudiant
void modifier_Etudiant() {
    int id_a_modifier;
    char ligne[256];
    FILE *fichier = fopen("etudiants.csv", "r+");
    FILE *fichier_temp = fopen("temp.csv", "w");

    if (fichier == NULL || fichier_temp == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier.\n");
        return;
    }

    printf("ID de l'etudiant a modifier : ");
    scanf("%d", &id_a_modifier);
    getchar();  // Consommer le retour a la ligne restant

    int found = 0;
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);

        if (e.id == id_a_modifier) {
            found = 1;
            printf("Modifier le nom (actuel : %s) : ", e.nom);
            fgets(e.nom, sizeof(e.nom), stdin);
            e.nom[strcspn(e.nom, "\n")] = 0;  // Enlever le retour a la ligne

            printf("Modifier le prenom (actuel : %s) : ", e.prenom);
            fgets(e.prenom, sizeof(e.prenom), stdin);
            e.prenom[strcspn(e.prenom, "\n")] = 0;  // Enlever le retour a la ligne
        }

        fprintf(fichier_temp, "%d,%s,%s\n", e.id, e.nom, e.prenom);
    }

    fclose(fichier);
    fclose(fichier_temp);
    remove("etudiants.csv");
    rename("temp.csv", "etudiants.csv");

    if (found) {
        printf("Etudiant modifie avec succes !\n");
    } else {
        printf("Etudiant non trouve.\n");
    }
}

// Fonction pour supprimer un etudiant
void supprimer_Etudiant() {
    int id_a_supprimer;
    char ligne[256];
    FILE *fichier = fopen("etudiants.csv", "r");
    FILE *fichier_temp = fopen("temp.csv", "w");

    if (fichier == NULL || fichier_temp == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier.\n");
        return;
    }

    printf("ID de l'etudiant a supprimer : ");
    scanf("%d", &id_a_supprimer);
    getchar();  // Consommer le retour a la ligne restant

    int found = 0;
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);

        if (e.id != id_a_supprimer) {
            fprintf(fichier_temp, "%d,%s,%s\n", e.id, e.nom, e.prenom);
        } else {
            found = 1;
        }
    }

    fclose(fichier);
    fclose(fichier_temp);
    remove("etudiants.csv");
    rename("temp.csv", "etudiants.csv");

    if (found) {
        printf("Etudiant supprime avec succes !\n");
    } else {
        printf("Etudiant non trouve.\n");
    }
}

// Fonction pour ajouter un cours
void ajouter_Cours() {
    Cours c;
    FILE *fichier = fopen("cours.csv", "a");

    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier.\n");
        return;
    }

    printf("ID du cours : ");
    scanf("%d", &c.id);
    getchar();  // Consommer le retour a la ligne restant

    printf("Nom du cours : ");
    fgets(c.nom, sizeof(c.nom), stdin);
    c.nom[strcspn(c.nom, "\n")] = 0;  // Enlever le retour a la ligne

    fprintf(fichier, "%d,%s\n", c.id, c.nom);
    fclose(fichier);
    printf("Cours ajoute avec succes !\n");
}

// Fonction pour afficher les cours
void afficher_Cours() {
    FILE *fichier = fopen("cours.csv", "r");
    char ligne[256];

    if (fichier == NULL) {
        printf("Aucun cours enregistre.\n");
        return;
    }

    printf("----------------------------------------------------------\n");
    printf("| ID | Nom                |\n");
    printf("----------------------------------------------------------\n");

    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        Cours c;
        sscanf(ligne, "%d,%[^,]", &c.id, c.nom);
        printf("| %2d | %-18s |\n", c.id, c.nom);
    }

    printf("----------------------------------------------------------\n");
    fclose(fichier);
}

// Fonction pour ajouter une note

void ajouter_Note() {
    int id_etudiant, id_cours;
    float note;

    printf("ID de l'etudiant : ");
    scanf("%d", &id_etudiant);
    printf("ID du cours : ");
    scanf("%d", &id_cours);
    printf("Note : ");
    scanf("%f", &note);

    // Ouvrir le fichier des notes en mode ajout
    FILE *fichier_notes = fopen("notes.csv", "a");

    if (fichier_notes == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier des notes.\n");
        return;
    }

    // �crire la note dans le fichier
    fprintf(fichier_notes, "%d,%d,%.2f\n", id_etudiant, id_cours, note);
    fclose(fichier_notes);

    printf("Note ajout�e avec succes pour l'�tudiant ID %d dans le cours ID %d.\n", id_etudiant, id_cours);
}

// Fonction pour ajouter une absence
void ajouter_Absence() {
    int id_etudiant, id_cours;

    // Demander l'ID de l'�tudiant et du cours
    printf("ID de l'etudiant : ");
    scanf("%d", &id_etudiant);
    printf("ID du cours : ");
    scanf("%d", &id_cours);

    // Ouvrir le fichier des absences en mode ajout
    FILE *fichier_absences = fopen("absences.csv", "a");

    if (fichier_absences == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier des absences.\n");
        return;
    }

    // �crire l'absence dans le fichier
    fprintf(fichier_absences, "%d,%d\n", id_etudiant, id_cours);
    fclose(fichier_absences);

    printf("Absence ajout�e avec succes pour l'etudiant ID %d dans le cours ID %d.\n", id_etudiant, id_cours);
}

void generer_Rapport() {
    FILE *fichier_etudiants = fopen("etudiants.csv", "r");
    FILE *fichier_notes = fopen("notes.csv", "r");
    FILE *fichier_absences = fopen("absences.csv", "r");
    FILE *fichier_rapport = fopen("rapport.csv", "w");
    char ligne[256];

    if (fichier_etudiants == NULL) {
        printf("Aucun �tudiant enregistre.\n");
        return;
    }

    // �crire l'en-t�te du rapport
    fprintf(fichier_rapport, "ID,Nom,Prenom,Note,Absences\n");

    // Lire les �tudiants et g�n�rer le rapport
    while (fgets(ligne, sizeof(ligne), fichier_etudiants) != NULL) {
        Etudiant e;
        sscanf(ligne, "%d,%[^,],%s", &e.id, e.nom, e.prenom);

        // Initialiser note et absences
        float note = -1; // -1 signifie pas de note
        int absences = 0;

        // V�rifier les notes
        rewind(fichier_notes);
        while (fgets(ligne, sizeof(ligne), fichier_notes) != NULL) {
            int id_etudiant, id_cours;
            float note_temp;
            sscanf(ligne, "%d,%[^,],%d,%f", &id_etudiant, e.nom, &id_cours, &note_temp);
            if (id_etudiant == e.id) {
                note = note_temp; // Prendre la note la plus r�cente
            }
        }

        // V�rifier les absences
        rewind(fichier_absences);
        while (fgets(ligne, sizeof(ligne), fichier_absences) != NULL) {
            int id_etudiant, id_cours, nombre_absences;
            sscanf(ligne, "%d,%d,%d", &id_etudiant, &id_cours, &nombre_absences);
            if (id_etudiant == e.id) {
                absences += nombre_absences; // Additionner les absences
            }
        }

        // �crire les informations dans le rapport
        fprintf(fichier_rapport, "%d,%s,%s,%.2f,%d\n", e.id, e.nom, e.prenom, note, absences);
        printf("ID: %d, Nom: %s, Prenom: %s, Note: %.2f, Absences: %d\n", e.id, e.nom, e.prenom, note, absences);
    }

    fclose(fichier_etudiants);
    fclose(fichier_notes);
    fclose(fichier_absences);
    fclose(fichier_rapport);
    printf("Le rapport a ete genere avec succes dans le fichier rapport.csv.\n");
}

