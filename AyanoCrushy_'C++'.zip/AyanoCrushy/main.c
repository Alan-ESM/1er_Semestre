#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "Etudiants.h"

// D�finitions des couleurs ANSI
#define RED     "\x1B[31m"
#define GREEN   "\x1B[32m"
#define YELLOW  "\x1B[33m"
#define BLUE    "\x1B[34m"
#define MAGENTA "\x1B[35m"
#define CYAN    "\x1B[36m"
#define RESET   "\x1B[0m"

#define MAX_COURS 50



// Fonction principale
int main() {
    int choix;
    char reponse[10];

    printf("\n\n\t\t\tKon'nichiwa chers Okyoku-sama j'espere que vous allez bien !\n");
    printf("\n\t\tOh! Veuillez pardonner mon impolitesse j'en oublie mes manieres, dites :\n ");
    printf("\t\tEtes-vous un otaku ? ("GREEN" oui "RESET"/"RED"non"RESET") : \n");
    printf("\n\tDite la verite s'il vous plait ! ");
    fgets(reponse, sizeof(reponse), stdin);
    reponse[strcspn(reponse, "\n")] = 0;

    if (strcasecmp(reponse, "oui") == 0) {
        printf(BLUE"Bienvenue, otaku !\n"RESET);
        printf(RED"A vos risques et peril si vous avez menti !\n"RESET);
        menu();
    } else {
        menu_non_otaku();
    }

    return 0;
}
