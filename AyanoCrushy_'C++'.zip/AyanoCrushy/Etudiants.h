#ifndef ETUDIANTS_H_INCLUDED
#define ETUDIANTS_H_INCLUDED

void ajouterEtudiant();
void modifierEtudiant();
void supprimerEtudiant();
void ajouterCours();
void afficherEtudiants();
void afficherCours();
void ajouterNote();
void ajouterAbsence();
void genererRapport();
void ajouter_Etudiant();
void modifier_Etudiant();
void supprimer_Etudiant();
void ajouter_Cours();
void afficher_Etudiants();
void afficher_Cours();
void ajouter_Note();
void ajouter_Absence();
void generer_Rapport();
void menu_non_otaku();
void menu();

#endif // ETUDIANTS_H_INCLUDED
