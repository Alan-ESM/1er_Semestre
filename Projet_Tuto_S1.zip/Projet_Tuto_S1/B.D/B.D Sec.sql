create type keys as enum ('correct', 'fausse');
CREATE TABLE UTILISATEURS (
    UTILISATEURS_ID INT PRIMARY KEY,
    Nom_UTILISATEURS VARCHAR(500) NOT NULL,
    Mot_de_Passe VARCHAR(500) NOT NULL,
    Role_app keys NOT NULL
);

INSERT INTO UTILISATEURS (UTILISATEURS_ID, Nom_UTILISATEURS, Mot_de_Passe, Role_app)
VALUES
(237001,'FOMEKONG Evaris','passe.fr02', 'correct'),
(237002,'Dinh Marcel','gmail.fr' ,'fausse'),
(237003,'Ayissi Alan', 'passe.fr02','correct'),
(237004,'Tcham Emilie','tabshift226' ,'fausse'),
(237005,'Ngah Paul','passe.fr02' ,'correct'),
(237006,'Mouangue Jessica','passe.fr02' ,'correct'),
(237007,'Djidja Samuel','gmail.fr@2216' ,'fausse');

select *from UTILISATEURS

