CREATE TABLE Client (
    ID_Client INT PRIMARY KEY,
    Points INT,
    Nom_Client VARCHAR(500) NOT NULL,
    Prenom_Client VARCHAR(500) NOT NULL,
    email VARCHAR(500) NOT NULL,
    Telephone VARCHAR(500) NOT NULL,
    Address VARCHAR(500) NOT NULL,
    Pourcentage_rabais DECIMAL(10, 2) NOT NULL
);

CREATE OR REPLACE FUNCTION calculate_discount()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.Points >= 100 AND NEW.Points < 300 THEN
        NEW.Pourcentage_rabais := 5;
    ELSIF NEW.Points >= 300 AND NEW.Points < 500 THEN
        NEW.Pourcentage_rabais := 10;
    ELSIF NEW.Points >= 500 AND NEW.Points < 800 THEN
        NEW.Pourcentage_rabais := 20;
    ELSIF NEW.Points >= 800 AND NEW.Points < 1100 THEN
        NEW.Pourcentage_rabais := 30;
    ELSIF NEW.Points >= 1100 AND NEW.Points < 1300 THEN
        NEW.Pourcentage_rabais := 40;
    ELSIF NEW.Points >= 1500 AND NEW.Points < 1800 THEN
        NEW.Pourcentage_rabais := 45;
    ELSIF NEW.Points >= 1800 AND NEW.Points < 2100 THEN
        NEW.Pourcentage_rabais := 50;
    ELSIF NEW.Points >= 2100 AND NEW.Points < 2300 THEN
        NEW.Pourcentage_rabais := 55;
    ELSIF NEW.Points >= 2500 AND NEW.Points < 2800 THEN
        NEW.Pourcentage_rabais := 60;
    ELSIF NEW.Points >= 3100 AND NEW.Points < 3300 THEN
        NEW.Pourcentage_rabais := 65;
    ELSIF NEW.Points >= 3300 AND NEW.Points < 3500 THEN
        NEW.Pourcentage_rabais := 30;
    ELSIF NEW.Points >= 3500 AND NEW.Points < 3800 THEN
        NEW.Pourcentage_rabais := 75;
    ELSIF NEW.Points >= 3800 AND NEW.Points < 4100 THEN
        NEW.Pourcentage_rabais := 80;
    ELSIF NEW.Points >= 4100 AND NEW.Points < 4300 THEN
        NEW.Pourcentage_rabais := 85;
    ELSIF NEW.Points >= 4300 AND NEW.Points < 4500 THEN
        NEW.Pourcentage_rabais := 40;
    ELSIF NEW.Points >= 4500 AND NEW.Points < 4600 THEN
        NEW.Pourcentage_rabais := 95;
    ELSIF NEW.Points >= 4600 THEN
        NEW.Pourcentage_rabais := 100;
    ELSE
        NEW.Pourcentage_rabais := 0; -- Default value if no conditions are met
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_discount
BEFORE INSERT ON Client
FOR EACH ROW
EXECUTE FUNCTION calculate_discount();

INSERT INTO Client (ID_Client, Points, Nom_Client, Prenom_Client, email, Telephone, Address)
VALUES
(237001, 887, 'FOMEKONG', 'Evaris', 'evaris.fmk@gmail.com', '655340420', 'Yaoundé'),
(237002, 505, 'Dinh', 'Marcel', 'dinh.fmmarcel@gmail.com', '656350520', 'Yaoundé'),
(237003, 1200, 'Ayissi', 'Alan', 'ayissi.alan@gmail.com', '656166903', 'Douala'),
(237004, 1351, 'Tcham', 'Emilie', 'emilie.tcham@gmail.com', '657340421', 'Yaoundé'),
(237005, 2250, 'Ngah', 'Paul', 'paul.ngah@gmail.com', '658350522', 'Douala'),
(237006, 3200, 'Mouangue', 'Jessica', 'jessica.mouangue@gmail.com', '659340423', 'Yaoundé'),
(237007, 4600, 'Djidja', 'Samuel', 'samuel.djidja@gmail.com', '660350524', 'Douala'); 

select *from Client