create Table categories(
ID_Categorie INT primary key,
Nom_categorie VARCHAR(500) not null
);
CREATE TABLE Produits (
    Produit_ID INT PRIMARY KEY,
    Nom_Produit VARCHAR(500) NOT NULL,
    Description VARCHAR(500) NOT NULL,
    Categorie VARCHAR(500) NOT NULL,
	Quantite VARCHAR(500) NOT NULL,
    Prix DECIMAL(10, 2) NOT NULL
);

INSERT INTO categories (ID_Categorie, Nom_categorie)
VALUES
(1,'Mangas et bandes dessinees'),
(2,'anime et serie televisee'),
(3,'figurines et statuts'),
(4,'merchandising'),
(5,'jeu video'),
(6,'musique'),
(7,'nouriture et boissons'),
(8,'cosmetique et soins'),
(9,'decoration et mobilier'),
(10,'decoration et mobilier'),
(11,'jeux et loisirs'),
(12,'instruments de musique'),
(13,'art et craft'),
(14,'litterature et educations'),
(15,'cadeaux et souvenir');


INSERT INTO Produits (Produit_ID, Nom_Produit, Description, Categorie, Quantite, Prix)
VALUES 
(1000000001, 'tomes Naruto', 'decouvrez le vecu captivant de Naruto Uzumaki.', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000002, 'Tomes One Piece', 'Monkey D Luffy sera t-il le futur roi des pirates', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000003, 'Tomes Dragon ball', 'decouvrez les aventures captivantes de Son Goku', 'Mangas et bandes dessinees', 100, 4000.00),
(1000000004, 'Tomes Attack des titans', 'Eren Yeager verra t-il son reve se realiser', 'Mangas et bandes dessinees', 100, 6000.00),
(1000000005, 'Tomes Jojo bizarre Adventure', 'jojo reussira t-il a proteger sa famille', 'Mangas et bandes dessinees', 100, 4000.00),
(1000000006, 'Tomes Fullmetal Alchemist', 'les freres ELRIC trouveront-ils la Pierre philosophale.', 'Mangas et bandes dessinees', 100, 4500.00),
(1000000007, 'Tomes Bleach', 'Ichigo Kurosaki pourra t-il sauver le monde des Hollows?', 'Mangas et bandes dessinees', 100, 4500.00),
(1000000008, 'Tomes Sailor moon', 'Bunny Tsukino fera t-elle une bonne Sailor Moon?', 'Mangas et bandes dessinees', 100, 3000.00),
(1000000009, 'Tome Haikyu!!', 'Shoyo Hinata et son equipe devienfront-ils les champions du volley ball?.', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000010, 'Tomes Jujutsu Kaisen', 'Yuji Itadori pourra t-il controler sukuna et sauver l humanite des curses.', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000011, 'Tomes demon slayer', 'Kamado Tanjiro pourra t-il aneantir Kibutsuji Muzan et sauver sa soeur.', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000012, 'Tomes Solo leveling', 'decouvrez les aventures de Sung Jin Woo.', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000013, 'Tomes A salaryman', 'Dennosuke Uchimura survivra t-il en tant que serviteur du roi demon?.', 'Mangas et bandes dessinees', 100, 5000.00),
(1000000015, 'tomes des Carnets de l apothicaire', 'Mao Mao survivra t-elle dans le palais de l empereur.', 'Mangas et bandes dessinees', 100, 7000.00),
(1000000017, 'Blu-ray Naruto', 'revivez les aventures du ninja temeraire Naruto par saisons', 'anime et serie televisee', 100, 16500.00),
(1000000018, 'Blu-ray One Peace', 'ayez les peripeties de Monkey D Luffy a porte de mains.', 'anime et serie televisee', 100, 15000.00),
(1000000019, 'Blu-ray Dragon ball', 'toutes les aventures de Goku sur votre disque disponible.', 'anime et serie televisee', 100, 16500.00),
(1000000020, 'Blu-ray Attack on Titan', 'Replongez le vecu de Eren Yeager et son reve de vie hors des murs.', 'anime et serie televisee', 100, 18900.00),
(1000000021, 'Blu-ray Fullmetal Alchemist Brotherhood', 'revivez les aventures des freres Elrick.', 'anime et serie televisee', 100, 19800.00),
(1000000022, 'Blu-ray Death Note', 'revivez les peripeties de Light Yagami detenteur du livre de la mort.', 'anime et serie televisee', 100, 13200.00),
(1000000023, 'Blu-ray Bleach', 'repassez les aventures de Ichigo kurosaki.', 'anime et serie televisee', 100, 22300.00),
(1000000024, 'Blu-ray Sailor Moon', 'complet sailor moon dispo', 'anime et serie televisee', 100, 18900.00),
(1000000025, 'DVD JoJo s Bizarre Adventure', 'tout l aventure à Jojo disponible', 'anime et serie televisee', 100, 17900.00),
(1000000026, 'Blu-ray Haikyuu!!', 'La passion du jeune joueur de volley Hinata', 'anime et serie televisee', 100, 22800.00),
(1000000027, 'Blu-ray jujutsu kaisen', 'plongez dans l univers sombre et captivant de jujutsu kaisen', 'anime et serie televisee', 100, 26900.00),
(1000000028, 'Blu-ray demon slayer', 'replongez dans les aventures de kamado Tanjiro', 'anime et serie televisee', 100, 25400.00),
(1000000029, 'Blu-ray solo leveling', 'revivez les aventures captivantes de sung jin', 'anime et serie televisee', 100, 22700.00),
(1000000030, 'Blu-ray Dr stone', 'dans la quete pour reconstruire la civilisation suivez les aventures de senku et de ses amis', 'anime et serie televisee', 100, 17300.00),
(1000000031, 'Blu ray les carnets de l apothicaire', 'plongez dans un univers mysterieux et enchanteur avec les carnets de notre apothicaire', 'anime et serie televisee', 100, 16400.00),
(1000000033, 'Figurine Naruto Uzumaki (Naruto)', 'ayez votre Naruto miniature à portee de poche.', 'figurines et statuts', 100, 15000.00),
(1000000034, 'Statue Goku (Dragon Ball Z)', 'votre sayan disponible en miniature', 'figurines et statuts', 100, 19800.00),
(1000000035, 'Figurine Light Yagami', 'L et N (Death Note) les genies du death note a portee de main', 'figurines et statuts', 100, 25400.00),
(1000000036, 'Statue Lelouch vi Britannia (Code Geass)', 'un Lelouche à la maison rien que pour vous', 'figurines et statuts', 100, 22600.00),
(1000000037, 'Figurine Edward et Alphonse Elric (Fullmetal)', 'obtenez votre Full metal alchemist et son frere chez vous', 'figurines et statuts', 100, 25900.00),
(1000000038, 'figurine Roronoa Zoro (One Peace)', 'Et si vous pouviez apporter votre epeiste prefere avec vous', 'figurines et statuts', 100, 17300.00),
(1000000039, 'Figurine Mikasa Ackerman', 'Eren Yeager et Armin Arlet notre trio desormais chez vous', 'figurines et statuts', 100, 25700.00),
(1000000040, 'Figurine complete equipe 7 (Naruto)', 'gardez chez vous votre equipe Kakakshi', 'figurines et statuts', 100, 30800.00),
(1000000041, 'Figurine Monkey D. Luffy (One Piece)', 'Monkey D Luffy le pirate au chapeau de paille', 'figurines et statuts', 100, 19700.00),
(1000000042, 'Statue Ichigo Kurosaki (Bleach)', 'Ichigo comme vous ne l avez jamais vu', 'figurines et statuts', 100, 14900.00),
(1000000043, 'Figurine Seishiro Nagi (blue lock)', 'le chouchou de Blue Lock desormais disponible en miniature', 'figurines et statuts', 100, 22400.00),
(1000000044, 'figurine Madara Uchiwa', 'le leader legendaire du clan Uchiwa desormais disponible en model reduit', 'figurines et statuts', 100, 18900.00),
(1000000045, 'figurine Anya Forger (spy x family)', 'recevez enfin votre deuteragoniste favoris sur tous ces angles', 'figurines et statuts', 100, 14900.00),
(1000000046, 'plateau figurines mix animes', 'commandez desormais votre plateau de 5 figurines animes mixte', 'figurines et statuts', 100, 40000.00),
(1000000047, 'Figurine Limule', 'commandez votre figurine du roi dragon Limule', 'figurines et statuts', 100, 15000.00),
(1000000049, 'T-shirt Naruto', 'Un coffret vibrant pour les fans de One Piece', 'merchandising', 50, 35000.00),
(1000000050, 'Clés USB Dragon Ball Z 256Go', 'Stockez vos donnees avec style grace a cette cle USB Dragon Ball Z.', 'merchandising', 75, 24900.00),
(1000000051, 'Collier animes', 'Un collier elegant pour les fans d animés.', 'merchandising', 120, 5900.00),
(1000000052, 'T-shirt Fullmetal Alchemist', 'Montrez votre amour pour Fullmetal Alchemist avec ce T-shirt.', 'merchandising', 100, 9900.00),
(1000000053, 'coffret Death Note', 'Un coffret surprise pour les fans de Death Note', 'merchandising', 50, 10000.00),
(1000000054, 'Clés USB Bleach 256Go', 'Cle USB Bleach pour stocker vos fichiers avec style.', 'merchandising', 75, 24900.00),
(1000000055, 'Coffret Accessoire Sailor Moon', 'Un coffret rempli d accessoires de Sailor Moon.', 'merchandising', 40, 49900.00),
(1000000056, 'T-shirt JoJo s Bizarre Adventure', 'Exprimez-vous avec ce T-shirt JoJo s.', 'merchandising', 100, 9500.00),
(1000000057, 'poster animes', 'Un poster pour tous les amateurs d animes.', 'merchandising', 50, 2000.00),
(1000000058, 'Bracelet theme animes', 'Un bracelet pour afficher votre passion pour les animes.', 'merchandising', 100, 2900.00),
(1000000059, 'Coffret accessoires Demon Slayer', 'Coffret d accessoires inspires de Demon Slayer.', 'merchandising', 40, 49900.00),
(1000000060, 'T-shirt Dandadan', 'Montrez votre style avec ce T-shirt Dandadan.', 'merchandising', 100, 19900.00),
(1000000061, 'Pupilles themes animes', 'voyez univers anime.', 'merchandising', 80, 15900.00),
(1000000062, 'Bracelet Ying et Yang', 'Un bracelet symbolisant l harmonie.', 'merchandising', 100, 2900.00),
(1000000063, 'Collier Nisekoi', 'Collier inspiré de l animé Nisekoi.', 'merchandising', 100, 7500.00),
(1000000064, 'Micro Ai Hoshino', 'Micro inspire de l anime Oshi No Ko', 'merchandising', 100, 9900.00),
(1000000066, 'Naruto Ultimate Ninja Storm 4 (PS4)', 'Vivez des combats épiques dans Naruto: Ultimate Ninja Storm 4.', 'jeu video', 50, 59900.00),
(1000000067, 'One Piece: Burning Blood (PS4)', 'Affrontez vos amis dans des combats de pirate dans One Piece: Burning Blood.', 'jeu video', 50, 49900.00),
(1000000068, 'Dragon Ball Xenoverse 2 (PS4)', 'Decouvrez un monde ouvert dans Dragon Ball Xenoverse 2.', 'jeu video', 50, 59900.00),
(1000000069, 'Attack on Titan 2 (PS4)', 'Combattez des titans dans Attack on Titan 2.', 'jeu video', 50, 59900.00),
(1000000070, 'Fullmetal Alchemist Brotherhood (PS2)', 'Plongez dans l univers de Fullmetal Alchemist dans ce jeu PS2.', 'jeu video', 50, 29900.00),
(1000000071, 'Death Note L Change the World (PS2)', 'Resolvez des mysteres dans Death Note: L Change the World.', 'jeu video', 30, 24900.00),
(1000000072, 'Bleach Soul Resurreccion (PS3)', 'Combattez avec vos personnages preferes dans Bleach: Soul Resurreccion.', 'jeu video', 40, 39900.00),
(1000000073, 'Sailor Moon: Another Story (SNES)', 'Un RPG classique avec les héroïnes de Sailor Moon.', 'jeu video', 35, 19900.00),
(1000000074, 'JoJos Bizarre Adventure All-Star Battle (PS3)', 'Un combat intense avec les personnages de JoJo s Bizarre Adventure.', 'jeu video', 50, 49900.00),
(1000000075, 'Haikyuu!! Tsunage! Itadaki no Kesho (3DS)', 'Un jeu de volley inspiré de l anime Haikyuu!!', 'jeu video', 30, 29900.00),
(1000000076, 'Naruto Ultimate Ninja Storm 5 (PS4 Xbox One PC)', 'Continuez l aventure Naruto dans ce nouveau jeu.', 'jeu video', 50, 59900.00),
(1000000077, 'Overwatch (PC PS4 Xbox One)', 'Un jeu de tir en équipe avec des heros uniques.', 'jeu video', 100, 49900.00),
(1000000078, 'Elsword Evolution (PS4 Xbox One)', 'Un MMORPG d action avec des personnages animés.', 'jeu video', 100, 29900.00),
(1000000079, 'Gundam Versus (PS4)', 'Combattez avec des Mobile Suits dans Gundam Versus.', 'jeu video', 40, 59900.00),
(1000000080, '', 'Explorez le monde de One Piece dans cette aventure.', 'jeu video', 50, 60000.00),
(1000000081, 'My Hero One s Justice 2 (PS4 Xbox One Switch)', 'Battez-vous avec des héros et des vilains de My Hero Academia.', 'jeu video', 50, 59900.00),
(1000000082, 'Demon Slayer Kimetsu no Yaiba The Hinokami', 'Combattez des demons dans l univers de Demon Slayer.', 'jeu video', 50, 59900.00),
(1000000083, 'One Punch Man A Hero Nobody Knows (PS4 Xbox One)', 'Devenez un héros dans l univers de One Punch Man.', 'jeu video', 50, 49900.00),
(1000000085, 'CD Naruto Best Hit Collection', 'Collection des meilleurs hits de Naruto.', 'musique', 100, 19900.00),
(1000000086, 'CD One Piece Super Best', 'Les meilleures chansons de One Piece.', 'musique', 100, 19900.00),
(1000000087, 'CD Dragon Ball Z Best of DBZ', 'Les chansons emblématiques de Dragon Ball Z.', 'musique', 100, 19900.00),
(1000000088, 'CD Attack on Titan Original Soundtrack', 'Bande originale d Attack on Titan.', 'musique', 50, 24900.00),
(1000000089, 'CD Fullmetal Alchemist Brotherhood Original Soundtrack', 'Bande originale de Fullmetal Alchemist Brotherhood.', 'musique', 50, 24900.00),
(1000000090, 'CD Death Note Original Soundtrack', 'Bande originale de Death Note.', 'musique', 50, 24900.00),
(1000000091, 'CD Bleach Original Soundtrack', 'Bande originale de Bleach.', 'musique', 50, 24900.00),
(1000000092, 'CD Sailor Moon Original Soundtrack', 'Bande originale de Sailor Moon.', 'musique', 50, 24900.00),
(1000000093, 'CD JoJos Bizarre Adventure Original Soundtrack', 'Bande originale de JoJo s Bizarre Adventure.', 'musique', 50, 24900.00),
(1000000094, 'CD Haikyuu!! Original Soundtrack', 'Bande originale de Haikyuu!!', 'musique', 100, 19900.00),
(1000000095, 'CD Compilation des YOASOBI', 'Une compilation des meilleurs titres de YOASOBI.', 'musique', 100, 19900.00),
(1000000096, 'CD Popular Anime Openings and Endings (Top 100)', 'Les 100 meilleures ouvertures et fins d animés.', 'musique', 50, 29900.00),
(1000000097, 'CD Best of K-POP', 'Les meilleurs titres de K-POP.', 'musique', 50, 29900.00),
(1000000098, 'CD All of Demon Slayer', 'Une compilation des meilleurs morceaux de Demon Slayer.', 'musique', 50, 24900.00),
(1000000099, 'CD Your Name: Original Soundtrack', 'Bande originale du film Your Name.', 'musique', 50, 24900.00),
(1000000100, 'CD Spirited Away: Original Soundtrack', 'Bande originale du film Spirited Away.', 'musique', 50, 24900.00),
(1000000101, 'CD Cowboy Bebop: Original Soundtrack', 'Bande originale de Cowboy Bebop.', 'musique', 50, 24900.00),
(1000000103, 'Ramen instantané japonais', 'Ramen instantané pour un repas rapide et délicieux.', 'nourriture et boissons', 100, 19900.00),
(1000000104, 'Sachet de thé vert japonais', 'Thé vert japonais pour une pause rafraîchissante.', 'nourriture et boissons', 100, 15000.00),
(1000000105, 'Boîte de sushi préparé', 'parfait pour un déjeuner rapide.', 'nourriture et boissons', 50, 29900.00),
(1000000106, 'Boissons gazeuses', 'Boissons gazeuses pour accompagner vos repas.', 'nourriture et boissons', 200, 2500.00),
(1000000107, 'Piments coréens', 'Piments coréens pour relever vos plats.', 'nourriture et boissons', 80, 15000.00),
(1000000108, 'Sauce soja', 'Sauce soja pour assaisonner vos plats.', 'nourriture et boissons', 100, 5000.00),
(1000000109, 'Sac de riz japonais', 'Riz japonais parfait pour vos sushis et plats.', 'nourriture et boissons', 50, 29900.00),
(1000000110, 'Petits gâteaux', 'Délicieux petits gâteaux japonais pour le goûter.', 'nourriture et boissons', 100, 12000.00),
(1000000111, 'Boîtes de viande précuite pour ramens', 'Viande précuite idéale pour vos ramens faits maison.', 'nourriture et boissons', 60, 20000.00),
(1000000112, 'Paquets de bonbons japonais', 'Bonbons japonais variés pour les amateurs de douceurs.', 'nourriture et boissons', 100, 10000.00),
(1000000113, 'Bento', 'Bento complet pour un repas équilibré.', 'nourriture et boissons', 40, 29900.00),
(1000000114, 'Thé ginseng coréen', 'Thé ginseng pour un boost d énergie.', 'nourriture et boissons', 60, 15000.00),
(1000000115, 'Thé fruité', 'Thé fruité rafraîchissant parfait pour l été.', 'nourriture et boissons', 100, 12000.00),
(1000000116, 'Saké japonais', 'Saké japonais traditionnel idéal pour les soirées.', 'nourriture et boissons', 30, 39900.00),
(1000000117, 'Chips de wasabi', 'Chips croustillantes au goût piquant de wasabi.', 'nourriture et boissons', 80, 15000.00),
(1000000118, 'Pudding de matcha', 'Pudding crémeux au matcha pour les amateurs de douceurs.', 'nourriture et boissons', 50, 12000.00),
(1000000119, 'Fruits secs japonais', 'Mélange de fruits secs japonais pour une collation saine.', 'nourriture et boissons', 70, 15000.00),
(1000000120, 'Gelée de yuzu', 'Gelee delicieuse au goût de yuzu parfaite pour les desserts.', 'nourriture et boissons', 40, 10000.00),
(1000000122, 'Crème hydratante', 'Creme hydratante pour une peau douce et eclatante.', 'cosmetique et soins', 100, 19900.00),
(1000000123, 'Masque facial', 'Masque facial revitalisant pour un teint frais.', 'cosmetique et soins', 80, 15000.00),
(1000000124, 'Parfum', 'Parfum envoûtant pour une senteur unique.', 'cosmetique et soins', 50, 29900.00),
(1000000125, 'Shampooing', 'Shampooing doux pour tous types de cheveux.', 'cosmetique et soins', 100, 12000.00),
(1000000126, 'Conditionneur', 'Conditionneur nourrissant pour des cheveux brillants.', 'cosmetique et soins', 100, 12000.00),
(1000000127, 'Crème anti-âge', 'Creme anti-age pour une peau plus ferme.', 'cosmetique et soins', 50, 24900.00),
(1000000128, 'Pack soin des mains', 'Pack contenant tout pour des mains douces.', 'cosmetique et soins', 50, 19900.00),
(1000000129, 'Pack soin des pieds', 'Pack pour des pieds hydratés et doux.', 'cosmetique et soins', 50, 19900.00),
(1000000130, 'Palettes de maquillage', 'Palette de maquillage avec de nombreuses couleurs.', 'cosmetique et soins', 40, 29900.00),
(1000000131, 'Pack soins du visage', 'Pack complet pour un soin du visage.', 'cosmetique et soins', 50, 25000.00),
(1000000132, 'Pack soins de cheveux', 'Pack de soins pour des cheveux sains.', 'cosmetique et soins', 50, 25000.00),
(1000000133, 'Pack soins du corps', 'Pack complet pour le soin du corps.', 'cosmetique et soins', 50, 25000.00),
(1000000134, 'Pack soins pour bébés', 'Pack de soins doux pour la peau des bébés.', 'cosmetique et soins', 50, 19900.00),
(1000000135, 'Creme reparatrices', 'Crèmes réparatrices pour les peaux abîmées.', 'cosmetique et soins', 50, 19900.00),
(1000000136, 'Coffret maquillage thème animé', 'Coffret de maquillage inspiré par les personnages animés.', 'cosmetique et soins', 30, 39900.00),
(1000000137, 'Gelée de purification au yuzu', 'Gelée légère au yuzu pour une peau éclatante.', 'cosmetique et soins', 50, 19900.00),
(1000000138, 'Crème de nuit au matcha', 'Crème de nuit enrichie au matcha pour régénérer la peau.', 'cosmetique et soins', 40, 24900.00),
(1000000139, 'Masque en tissu Sakura', 'Masque en tissu infusé aux fleurs de Sakura pour hydrater la peau.', 'cosmetique et soins', 60, 15000.00),
(1000000141, 'Yukata complet', 'Yukata traditionnel japonais parfait pour les festivals d été.', 'vetements et accessoires', 50, 49900.00),
(1000000142, 'Chaussures', 'Chaussures élégantes adaptées à tous les styles.', 'vetements et accessoires', 100, 29900.00),
(1000000143, 'T-shirt', 'T-shirt confortable avec motifs japonais.', 'vetements et accessoires', 100, 19900.00),
(1000000144, 'Pantalons', 'Pantalons styles parfaits pour le quotidien.', 'vetements et accessoires', 80, 24900.00),
(1000000145, 'Jupes', 'Jupes élégantes adaptées à toutes les occasions.', 'vetements et accessoires', 70, 19900.00),
(1000000146, 'Écharpes', 'echarpes douces pour l hiver.', 'vetements et accessoires', 100, 15000.00),
(1000000147, 'Chapeaux', 'Chapeaux styles pour compléter votre look.', 'vetements et accessoires', 80, 19900.00),
(1000000148, 'Gants', 'Gants confortables pour les journées froides.', 'vetements et accessoires', 100, 12000.00),
(1000000149, 'Casques à oreilles', 'Casques mignons en forme d oreilles d animaux.', 'vetements et accessoires', 60, 25000.00),
(1000000150, 'Sac à dos', 'Sac à dos pratique et stylé pour le quotidien.', 'vetements et accessoires', 50, 29900.00),
(1000000151, 'Cosplay', 'Costumes de cosplay pour représenter vos personnages préférés.', 'vetements et accessoires', 30, 49900.00),
(1000000152, 'Cache oreilles', 'Cache oreilles doux et chaleureux.', 'vetements et accessoires', 100, 8000.00),
(1000000153, 'Bonnets', 'Bonnets tendance pour l hiver.', 'vetements et accessoires', 80, 12000.00),
(1000000154, 'Robes', 'Robes élégantes pour toutes les occasions.', 'vetements et accessoires', 50, 29900.00),
(1000000155, 'Sandales', 'Sandales confortables pour l été.', 'vetements et accessoires', 80, 19900.00),
(1000000156, 'Hakama traditionnel', 'Hakama traditionnel pour les cérémonies japonaises.', 'vetements et accessoires', 30, 59900.00),
(1000000157, 'Tote bag animé', 'Tote bag pratique avec des motifs d animés.', 'vetements et accessoires', 100, 15000.00),
(1000000158, 'Chaussettes a motifs kawaii', 'Chaussettes mignonnes avec des motifs kawaii.', 'vetements et accessoires', 150, 5000.00),
(1000000159, 'Veste en jean avec patchs', 'Veste en jean avec des patchs inspirés des mangas.', 'vetements et accessoires', 40, 34900.00),
(1000000160, 'Collier en perles japonaises', 'Collier élégant en perles japonaises.', 'vetements et accessoires', 60, 18000.00),
(1000000162, 'Lampes', 'Lampes élégantes pour illuminer votre intérieur.', 'decoration et mobilier', 50, 19900.00),
(1000000163, 'Tapis', 'Tapis confortables pour ajouter une touche chaleureuse.', 'decoration et mobilier', 30, 29900.00),
(1000000164, 'Nappes artisanales', 'Nappes faites à la main avec des motifs traditionnels.', 'decoration et mobilier', 80, 15000.00),
(1000000165, 'Decorations murales', 'Décorations murales pour embellir votre espace.', 'decoration et mobilier', 40, 25000.00),
(1000000166, 'Vases', 'Vases décoratifs pour vos fleurs préférées.', 'decoration et mobilier', 100, 12000.00),
(1000000167, 'Bougies', 'Bougies parfumées pour une ambiance chaleureuse.', 'decoration et mobilier', 150, 8000.00),
(1000000168, 'Rideaux', 'Rideaux élégants pour une touche de style.', 'decoration et mobilier', 70, 19900.00),
(1000000169, 'Tissus traditionnels', 'Tissus traditionnels pour vos projets de couture.', 'decoration et mobilier', 60, 15000.00),
(1000000170, 'Décorations lumineuses', 'Décorations lumineuses pour créer une ambiance magique.', 'decoration et mobilier', 50, 22000.00),
(1000000171, 'Statuettes', 'Statuettes artistiques pour embellir votre intérieur.', 'decoration et mobilier', 40, 18000.00),
(1000000172, 'Mobilier salon complet thème animé', 'Mobilier de salon inspiré des thèmes animés japonais.', 'decoration et mobilier', 10, 199000.00),
(1000000173, 'Mobilier cuisine complet thème animé', 'Mobilier de cuisine inspiré des thèmes animés japonais.', 'decoration et mobilier', 10, 199000.00),
(1000000174, 'Mobilier de jardin complet', 'Mobilier de jardin confortable et esthétique.', 'decoration et mobilier', 5, 250000.00),
(1000000175, 'Decorations florales', 'Arrangements floraux pour égayer votre espace.', 'decoration et mobilier', 60, 15000.00),
(1000000176, 'Meuble de rangement japonais', 'Meuble de rangement traditionnel japonais.', 'decoration et mobilier', 25, 79900.00),
(1000000177, 'Miroir décoratif', 'Miroir avec cadre décoratif pour votre intérieur.', 'decoration et mobilier', 30, 25000.00),
(1000000178, 'Table basse en bois', 'Table basse en bois parfaite pour votre salon.', 'decoration et mobilier', 20, 34900.00),
(1000000179, 'Horloge murale', 'Horloge murale au design unique.', 'decoration et mobilier', 40, 18000.00),
(1000000180, 'Pont décoratif en bois', 'Pont décoratif en bois pour votre jardin ou intérieur.', 'decoration et mobilier', 15, 50000.00),
(1000000181, 'Coussins décoratifs', 'Coussins décoratifs pour ajouter du confort.', 'decoration et mobilier', 100, 12000.00),
(1000000183, 'Jeux de societe', 'Jeux de societe divertissants pour toute la famille.', 'jeux et loisirs', 50, 39900.00),
(1000000184, 'Jeux de cartes', 'Jeux de cartes variés pour des heures de plaisir.', 'jeux et loisirs', 100, 15000.00),
(1000000185, 'Puzzles', 'Puzzles captivants pour les amateurs de défis.', 'jeux et loisirs', 80, 25000.00),
(1000000186, 'Livres de jeux', 'Livres de jeux avec des énigmes et des défis.', 'jeux et loisirs', 60, 20000.00),
(1000000187, 'Cartes de collection', 'Cartes de collection pour les passionnés.', 'jeux et loisirs', 150, 12000.00),
(1000000188, 'Jeux de rôle', 'Jeux de rôle immersifs pour des aventures inoubliables.', 'jeux et loisirs', 30, 49900.00),
(1000000189, 'Jeux de stratégie', 'Jeux de stratégie pour tester vos compétences tactiques.', 'jeux et loisirs', 40, 39900.00),
(1000000190, 'Casse-tête', 'Casse-tête stimulants pour les amateurs de défis.', 'jeux et loisirs', 100, 12000.00),
(1000000191, 'Jeux de dés', 'Jeux de dés amusants pour des soirées entre amis.', 'jeux et loisirs', 120, 8000.00),
(1000000192, 'Kits de bricolage', 'Kits de bricolage pour créer vos propres jeux.', 'jeux et loisirs', 50, 25000.00),
(1000000193, 'Jeux éducatifs', 'Jeux éducatifs pour apprendre en s amusant.', 'jeux et loisirs', 70, 22000.00),
(1000000194, 'Figurines de jeux', 'Figurines pour enrichir vos jeux de rôle.', 'jeux et loisirs', 50, 18000.00),
(1000000195, 'Accessoires de jeux', 'Accessoires divers pour améliorer vos expériences de jeu.', 'jeux et loisirs', 100, 10000.00),
(1000000197, 'Guitare', 'Guitare de style japonais avec un son riche.', 'instruments de musique', 30, 49900.00),
(1000000198, 'Violon', 'Violon traditionnel pour la musique classique et folklorique.', 'instruments de musique', 20, 59900.00),
(1000000199, 'Piano', 'Piano avec des sonorités inspirées de la culture japonaise.', 'instruments de musique', 15, 89900.00),
(1000000200, 'Batterie', 'Kit de batterie adapté pour différents styles musicaux.', 'instruments de musique', 10, 69900.00),
(1000000201, 'Flute', 'Flute en bambou pour une sonorité douce et apaisante.', 'instruments de musique', 50, 15000.00),
(1000000202, 'Harpe', 'Harpe élégante pour des mélodies délicates.', 'instruments de musique', 5, 120000.00),
(1000000203, 'Saxophone', 'Saxophone pour des sonorités jazzy et modernes.', 'instruments de musique', 10, 45000.00),
(1000000204, 'Trompette', 'Trompette brillante parfaite pour votre salon.', 'instruments de musique', 15, 35000.00),
(1000000205, 'Diapason', 'Diapason pour accorder vos instruments.', 'instruments de musique', 100, 5000.00),
(1000000206, 'Clochettes', 'Clochettes légères pour ajouter une touche musicale.', 'instruments de musique', 80, 8000.00),
(1000000207, 'Shamisen', 'Shamisen instrument à trois cordes de la musique japonaise.', 'instruments de musique', 10, 60000.00),
(1000000208, 'Koto', 'Koto instrument à cordes traditionnel japonais.', 'instruments de musique', 5, 90000.00),
(1000000209, 'Taiko', 'Taiko instrument à cordes traditionnel japonais.', 'instruments de musique', 8, 35000.00),
(1000000210, 'Naginata', 'Naginata instrument à vent traditionnel.', 'instruments de musique', 12, 25000.00),
(1000000211, 'Shakuachi', 'flûte en bambou pour des sonorités apaisantes.', 'instruments de musique', 15, 20000.00),
(1000000213, 'Peinture', 'Peintures inspirées des paysages et de la culture japonaise.', 'art et craft', 40, 25000.00),
(1000000214, 'Sculpture', 'Sculptures en bois ou en pierre représentant des motifs japonais.', 'art et craft', 15, 50000.00),
(1000000215, 'Dessin', 'Outils et fournitures pour le dessin inspiré de l art japonais.', 'art et craft', 50, 15000.00),
(1000000216, 'Collage', 'Matériaux pour créer des collages inspirés de la culture japonaise.', 'art et craft', 60, 12000.00),
(1000000217, 'Poterie', 'Poterie artisanale aux motifs japonais traditionnels.', 'art et craft', 20, 30000.00),
(1000000218, 'Tissage', 'Matériaux et outils pour le tissage inspiré de l art japonais.', 'art et craft', 30, 25000.00),
(1000000219, 'Broderie', 'Kits de broderie avec des motifs japonais traditionnels.', 'art et craft', 50, 18000.00),
(1000000220, 'Bijoux artisanaux', 'Bijoux faits main inspirés de la culture japonaise.', 'art et craft', 25, 22000.00),
(1000000221, 'Photographie', 'Matériel et livres sur la photographie inspirée du Japon.', 'art et craft', 40, 20000.00),
(1000000222, 'Gravure', 'Outils pour la gravure inspirée des motifs japonais.', 'art et craft', 15, 30000.00),
(1000000223, 'Calligraphie', 'Kits de calligraphie avec pinceaux et encres traditionnelles.', 'art et craft', 30, 15000.00),
(1000000224, 'Origami', 'Papier origami et livres pour créer des pliages japonais.', 'art et craft', 70, 8000.00),
(1000000225, 'Lanternes en papier', 'Lanternes en papier pour la décoration inspirée du Japon.', 'art et craft', 25, 18000.00),
(1000000226, 'Masques traditionnels', 'Masques artisanaux inspirés du théâtre japonais.', 'art et craft', 15, 22000.00),
(1000000227, 'Tampographe', 'Tampographe pour créer des impressions japonaises.', 'art et craft', 10, 20000.00),
(1000000229, 'Livres d histoire', 'Livres d histoire pour explorer les événements marquants.', 'litterature et education', 40, 25000.00),
(1000000230, 'Cartes', 'Cartes géographiques pour enrichir vos connaissances.', 'litterature et education', 100, 15000.00),
(1000000231, 'Cours en ligne', 'Accès à des cours en ligne sur divers sujets.', 'litterature et education', 20, 50000.00),
(1000000232, 'Collages éducatifs', 'Matériaux pour créer des collages éducatifs.', 'litterature et education', 60, 12000.00),
(1000000233, 'Revues', 'Revues sur divers sujets d actualité et de culture.', 'litterature et education', 80, 8000.00),
(1000000234, 'Magazines', 'Magazines traitant de la mode, de la science et de l art.', 'litterature et education', 90, 10000.00),
(1000000235, 'Livres de cuisine', 'Livres de cuisine avec des recettes du monde entier.', 'litterature et education', 50, 20000.00),
(1000000236, 'Ouvrages de fiction', 'Romans et nouvelles de divers genres littéraires.', 'litterature et education', 70, 18000.00),
(1000000237, 'Carnets d images', 'Carnets d images pour illustrer vos idées.', 'litterature et education', 40, 12000.00),
(1000000238, 'Manuels de langues', 'Manuels pour apprendre de nouvelles langues.', 'litterature et education', 30, 25000.00),
(1000000239, 'Livres pour enfants', 'Livres illustrés et éducatifs pour les jeunes lecteurs.', 'litterature et education', 50, 15000.00),
(1000000240, 'Dictionnaires', 'Dictionnaires pour enrichir votre vocabulaire.', 'litterature et education', 25, 20000.00),
(1000000241, 'Revues scientifiques', 'Revues détaillant les dernières recherches scientifiques.', 'litterature et education', 15, 30000.00),
(1000000242, 'Livres dart', 'Livres présentant des œuvres d art et des artistes célèbres.', 'litterature et education', 20, 35000.00),
(1000000244, 'Tasse personnalisee', 'Tasse personnalisable avec un message ou une image.', 'cadeaux et souvenirs', 50, 12000.00),
(1000000245, 'Aimants de refrigérateur', 'Aimants colorés représentant des paysages ou monuments.', 'cadeaux et souvenirs', 100, 5000.00),
(1000000246, 'Cle USB en bois', 'Clé USB élégante en bois parfaite pour un cadeau.', 'cadeaux et souvenirs', 30, 15000.00),
(1000000247, 'Coussins decoratifs', 'Coussins avec des motifs artistiques pour embellir votre intérieur.', 'cadeaux et souvenirs', 20, 30000.00),
(1000000248, 'Carnet de notes en cuir', 'Carnet de notes élégant avec une couverture en cuir.', 'cadeaux et souvenirs', 40, 25000.00),
(1000000249, 'Bougies parfumées', 'Bougies parfumées pour créer une ambiance chaleureuse.', 'cadeaux et souvenirs', 35, 18000.00),
(1000000250, 'Sacs en toile', 'Sacs en toile réutilisables avec des designs uniques.', 'cadeaux et souvenirs', 50, 20000.00),
(1000000251, 'Calendrier mural', 'Calendrier mural avec des photographies inspirantes.', 'cadeaux et souvenirs', 25, 15000.00),
(1000000252, 'Coffret de thé', 'Coffret de sélections de thés fins du monde entier.', 'cadeaux et souvenirs', 20, 35000.00),
(1000000253, 'Porte-clés', 'Porte-clés originaux avec des designs variés.', 'cadeaux et souvenirs', 80, 8000.00),
(1000000254, 'Posters artistiques', 'Posters d artistes contemporains pour décorer vos murs.', 'cadeaux et souvenirs', 45, 12000.00),
(1000000255, 'Masques décoratifs', 'Masques décoratifs pour ajouter une touche artistique.', 'cadeaux et souvenirs', 15, 22000.00),
(1000000256, 'Figurines de collection', 'Figurines de collection inspirées de la culture pop.', 'cadeaux et souvenirs', 10, 30000.00);

CREATE TABLE Client (
    ID_Client INT PRIMARY KEY,
    Points INT,
    Nom_Client VARCHAR(500) NOT NULL,
    email VARCHAR(500) NOT NULL,
    Telephone int,
    Address VARCHAR(500) NOT NULL,
    Pourcentage_rabais DECIMAL(10, 2) NOT NULL
);

CREATE OR REPLACE FUNCTION calculate_discount()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.Points >= 100 AND NEW.Points < 300 THEN
        NEW.Pourcentage_rabais := 5;
    ELSIF NEW.Points >= 300 AND NEW.Points < 500 THEN
        NEW.Pourcentage_rabais := 10;
    ELSIF NEW.Points >= 500 AND NEW.Points < 800 THEN
        NEW.Pourcentage_rabais := 20;
    ELSIF NEW.Points >= 800 AND NEW.Points < 1100 THEN
        NEW.Pourcentage_rabais := 30;
    ELSIF NEW.Points >= 1100 AND NEW.Points < 1300 THEN
        NEW.Pourcentage_rabais := 40;
    ELSIF NEW.Points >= 1500 AND NEW.Points < 1800 THEN
        NEW.Pourcentage_rabais := 45;
    ELSIF NEW.Points >= 1800 AND NEW.Points < 2100 THEN
        NEW.Pourcentage_rabais := 50;
    ELSIF NEW.Points >= 2100 AND NEW.Points < 2300 THEN
        NEW.Pourcentage_rabais := 55;
    ELSIF NEW.Points >= 2500 AND NEW.Points < 2800 THEN
        NEW.Pourcentage_rabais := 60;
    ELSIF NEW.Points >= 3100 AND NEW.Points < 3300 THEN
        NEW.Pourcentage_rabais := 65;
    ELSIF NEW.Points >= 3300 AND NEW.Points < 3500 THEN
        NEW.Pourcentage_rabais := 30;
    ELSIF NEW.Points >= 3500 AND NEW.Points < 3800 THEN
        NEW.Pourcentage_rabais := 75;
    ELSIF NEW.Points >= 3800 AND NEW.Points < 4100 THEN
        NEW.Pourcentage_rabais := 80;
    ELSIF NEW.Points >= 4100 AND NEW.Points < 4300 THEN
        NEW.Pourcentage_rabais := 85;
    ELSIF NEW.Points >= 4300 AND NEW.Points < 4500 THEN
        NEW.Pourcentage_rabais := 40;
    ELSIF NEW.Points >= 4500 AND NEW.Points < 4600 THEN
        NEW.Pourcentage_rabais := 95;
    ELSIF NEW.Points >= 4600 THEN
        NEW.Pourcentage_rabais := 100;
    ELSE
        NEW.Pourcentage_rabais := 0; -- Default value if no conditions are met
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_discount
BEFORE INSERT ON Client
FOR EACH ROW
EXECUTE FUNCTION calculate_discount();

INSERT INTO Client (ID_Client, Points, Nom_Client, email, Telephone, Address)
VALUES
(237001, 887, 'FOMEKONG Evaris', 'evaris.fmk@gmail.com', '655340420', 'Yaoundé'),
(237002, 505, 'Dinh Marcel', 'dinh.fmmarcel@gmail.com', '656350520', 'Yaoundé'),
(237003, 1200, 'Ayissi Alan', 'ayissi.alan@gmail.com', '656166903', 'Douala'),
(237004, 1351, 'Tcham Emilie', 'emilie.tcham@gmail.com', '657340421', 'Yaoundé'),
(237005, 2250, 'Ngah Paul', 'paul.ngah@gmail.com', '658350522', 'Douala'),
(237006, 3200, 'Mouangue Jessica', 'jessica.mouangue@gmail.com', '659340423', 'Yaoundé'),
(237007, 4600, 'Djidja Samuel', 'samuel.djidja@gmail.com', '660350524', 'Douala'); 


create type keys as enum ('correct', 'fausse');
CREATE TABLE UTILISATEURS (
    UTILISATEURS_ID INT PRIMARY KEY,
    Nom_UTILISATEURS VARCHAR(500) NOT NULL,
    Mot_de_Passe VARCHAR(500) NOT NULL,
    Role_app keys NOT NULL
);

INSERT INTO UTILISATEURS (UTILISATEURS_ID, Nom_UTILISATEURS, Mot_de_Passe, Role_app)
VALUES
(237001,'FOMEKONG Evaris','passe.fr02', 'correct'),
(237002,'Dinh Marcel','gmail.fr' ,'fausse'),
(237003,'Ayissi Alan', 'passe.fr02','correct'),
(237004,'Tcham Emilie','tabshift226' ,'fausse'),
(237005,'Ngah Paul','passe.fr02' ,'correct'),
(237006,'Mouangue Jessica','passe.fr02' ,'correct'),
(237007,'Djidja Samuel','gmail.fr@2216' ,'fausse');

create type mouvements as enum('entree','sortie');
CREATE TABLE Mouvements_Stock (
    id_mouvement INT PRIMARY KEY,
    type_mouvement mouvements,
    Date_de_mouvment date,
	Quantite INT,
	Produit_ID INT,
    FOREIGN KEY (Produit_ID) REFERENCES Produits(Produit_ID)
);

INSERT INTO Mouvements_Stock (id_mouvement,Produit_ID, Quantite, type_mouvement, Date_de_mouvment)
VALUES
(1,1000000001, 40, 'entree', '2025-02-05'),
(2,1000000008, 50, 'sortie', '2025-02-06'),
(3,1000000003, 20, 'entree', '2025-02-07'),
(4,1000000004, 20, 'entree', '2025-02-07'),
(5,1000000010, 30, 'sortie', '2025-02-08');

select *from Mouvements_Stock
select* from Produits
select* from categories
select *from UTILISATEURS
select *from Client