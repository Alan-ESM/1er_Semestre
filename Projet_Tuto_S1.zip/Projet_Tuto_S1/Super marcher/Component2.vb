﻿Public Class Component2

End Class
