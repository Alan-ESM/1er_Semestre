
#ifndef COMMANDES_H
#define COMMANDES_H

void acheterProduits();

#endif
