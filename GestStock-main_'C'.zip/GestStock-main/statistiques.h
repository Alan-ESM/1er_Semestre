
#ifndef STATISTIQUES_H
#define STATISTIQUES_H

void afficherStatistiques();

#endif
